# ------------------------------------------------------------------------------
#
#   Corrigé Exercices 11
#
#     Guillaume Guex
#
# ------------------------------------------------------------------------------


####---- 1. Pré-traitements et ACM ----####

# Chargement des librairies :
library(tidyverse)
library(readxl)
library(FactoMineR)
library(factoextra)

# Chargement et renommage des éléments :
pragmatique_df = read_excel("data/pragmatique.xlsx") %>%
  mutate(Direction = recode(Direction, "à l’intérieur" = "à l'intérieur"))

# Renommage 
pragmatique_df = pragmatique_df %>%
  rename(Position = `Position de l'UCT dans le TDP`)

# Construction de la table réduite :
pragmatique_red_df = pragmatique_df %>%
  select(Lemme, Genre, Position)

# MCA :
mca_res = MCA(pragmatique_red_df, graph=F)

# Information sur les deux premiers axes :
fviz_eig(mca_res, axes=c(1, 2))

####---- 2. Variables ----####

# Vecteur des nombres de modalité :
n_modalities = dim(table(pragmatique_red_df))

# Vecteur d'appartenance des modalités :
modality_type = c(rep(names(pragmatique_red_df)[1], n_modalities[1]),
                  rep(names(pragmatique_red_df)[2], n_modalities[2]),
                  rep(names(pragmatique_red_df)[3], n_modalities[3]))

# Affichage des variables :
fviz_mca_var(mca_res, col.var=modality_type, repel=T)

# Contribution modalité 
fviz_contrib(mca_res, choice="var", axes=c(1, 2))

# Corrélation des variables
fviz_mca_var(mca_res, choice="mca.cor")

####---- 3. Individus ----####

# Création du vecteur des genres 
genre = pragmatique_df$Genre

# Affichage des individus colorés par genre
fviz_mca_biplot(mca_res, geom.ind="point", col.ind=genre, addEllipses=T, 
                repel=T)

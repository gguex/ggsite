# ------------------------------------------------------------------------------
#
#   Corrigé Exercices 9
#
#     Guillaume Guex
#
# ------------------------------------------------------------------------------


####---- 1. Pré-traitements ----####

# Chargement des librairies :
library(tidyverse)
library(readtext)
library(quanteda)
library(FactoMineR)
library(factoextra)

# Chargement :
texts_df = readtext("data/20min/*.txt")

# Création de l'objet tokens :
corpus_obj = corpus(texts_df)
tokens_obj = tokens(corpus_obj, remove_punct=T, remove_symbols=T, 
                    remove_numbers=T, remove_url=T, 
                    remove_separators=T)

# Séparation par apostrophe et retrait des stopwords :
stopwords = readLines("data/stopwords/frenchST.txt")
tokens_obj = tokens_obj %>%
  tokens_split("'") %>%
  tokens_split("’") %>%
  tokens_remove(stopwords)

####---- 2. Création de la matrice termes-documents ----####

# Création de la matrice documents-termes :
dfm_df = dfm(tokens_obj) %>%
  convert(to="data.frame") %>%
  column_to_rownames("doc_id")

# Matrice documents-termes binaire :
dfm_binary_df = (dfm_df > 0)

# Sélection des termes apparaissant dans un seul document 
col_sup = which(colSums(dfm_binary_df) < 2)

# Sélection des documents sur le foot et fils lutteur
row_sup = c(3, 6, 7, 8)


####---- 3. l'AFC ----####

# Création de l'AFC :
ca_res = CA(dfm_df + 1e-50, graph=F, row.sup=row_sup, col.sup=col_sup)

# Inertie : il y a 39.5% d'inertie sur les 4 premières dimensions.
ca_res$eig

# Biplot axes 1-2 :
fviz_ca_biplot(ca_res, repel=T, select.col=list(contrib=80))

# Biplot axes 3-4 :
fviz_ca_biplot(ca_res, axes=c(3, 4), repel=T, select.col=list(contrib=80))

# Mots contribuant le plus aux axes 1-2 : 
ca_res$col$contrib %>%
  as_tibble(rownames=NA) %>%
  rownames_to_column() %>%
  mutate(contrib12=`Dim 1` + `Dim 2`) %>%
  arrange(desc(contrib12))

# Dans les 10 mots avec le plus de contribution aux 2 premiers axes, on trouve
# les mots en rapport avec la guerre en Ukraine et le rachat du Crédit Suisse 
# par UBS, i.e. les deux pôles de l'actualité hors Football.

  






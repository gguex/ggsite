# ------------------------------------------------------------------------------
#
# TP: Introduction à l'analyse de données en sciences humaines et sociales
#
#   Corrigé Exercices 10
#
#     Guillaume Guex
#
# ------------------------------------------------------------------------------


####---- 1. Pré-traitements ----####

# Chargement des librairies :
library(tidyverse)
library(leaps)

# Chargement du jeu de données 
socioling_df = read_csv("data/sociolinguistique_v2.csv")

# Tableau réduit 
socioling_red_df = socioling_df %>%
  select(c(annee, Hashtag:Craft))

####---- 2. Régressions linaires ----####

# Le modèle complet
lm_complet_res = lm(annee ~ ., data=socioling_red_df)
summary(lm_complet_res)

# Le coefficient le plus significatif est "Chill". Son utilisation prédit 
# une date de naissance de 13.6 années plus grande.

# Le R^2 est de 0.7337 et le R^2 est de 0.591.

# La sélection de modèle
lm_subset_res = regsubsets(annee ~ ., data=socioling_red_df)

# Le graphique du BIC 
plot(lm_subset_res, scale="bic")

# Les variables a retenir sont "Hashtag", "Parking", "Meeting", "Cool", "Chill",
# "E-mail", "Tea-room" et "Redingote".

# Le modèle optimal, le R^2 est de 0.6093 et le R^2 est de 0.5793.
lm_optimal_res = lm(annee ~ Hashtag + Parking + Meeting + Cool + Chill +
                      `E-mail` + `Tea-room` + Redingote, data=socioling_red_df)
summary(lm_optimal_res)

# Les utilisations de "Parking", "Meeting", "Tea-room" et "Redingote" 
# augmentent l'âge prédit.

# Diagramme des résidus - aucune structure particulière
ggplot() + 
  geom_point(aes(x=lm_optimal_res$fitted.values, lm_optimal_res$residuals))


# Construction d'un tableau d'une personne utilisant "Hashtag", "Cool" et 
# "Chill", et une autre utilisant "Tea-room" et "Redingote".
new_data = tibble(Hashtag=c(1, 0),
                  Parking=c(0, 0), 
                  Meeting=c(0, 0),
                  Cool=c(1, 0),
                  Chill=c(1, 0),
                  `E-mail`=c(0, 0),
                  `Tea-room`=c(0, 1),
                  Redingote=c(0, 1))
new_data

# Prédiction
predict(lm_optimal_res, new_data)

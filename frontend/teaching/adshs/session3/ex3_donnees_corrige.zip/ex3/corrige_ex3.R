# ------------------------------------------------------------------------------
#
#   Corrigé Exercices 3
#
#     Guillaume Guex
#
# ------------------------------------------------------------------------------



####---- 1. Préparation des données: `pragmatique.xlsx` ----####

# Chargement des librairies
library(tidyverse)
library(readxl)
library(DescTools)

# Chargement du jeu de données pragmatique et affichage des modalités de Lemme
pragmatique_df = read_excel("data/pragmatique.xlsx")

# Observation des modalité la variable Lemme
unique(pragmatique_df$Lemme)

# Transformation de Lemme et vérification
pragmatique_df = pragmatique_df %>%
  mutate(Lemme=str_squish(Lemme))
unique(pragmatique_df$Lemme)

# Nombre de syllabes
pragmatique_df = pragmatique_df %>%
  mutate(n_syllabes=case_when(
    Lemme == "SEMBLER" ~ 2,
    Lemme == "PARAÎTRE" ~ 2,
    Lemme == "AVOIR L'AIR" ~ 3,
    Lemme == "AVOIR L'IMPRESSION" ~ 5,
    Lemme == "DONNER L'IMPRESSION" ~ 5,
    Lemme == "APPAREMMENT" ~ 4,
    Lemme == "EVIDEMMENT" ~ 4,
    Lemme == "MANIFESTEMENT" ~ 5,
    Lemme == "VISIBLEMENT" ~ 4)
    )

# Durée moyenne
pragmatique_df = pragmatique_df %>%
  mutate(Durée= `Timing fin` - `Timing début`)

####---- 2. Statistiques uni- et bi-variées ----####

# Statistiques n_syllabes :
pragmatique_df %>%
  summarize(m_syl=mean(n_syllabes), med_syl=median(n_syllabes),
            sd_syl=sd(n_syllabes))

# Statistiques Durée :
pragmatique_df %>%
  reframe(quant_Durée=quantile(Durée, c(0.25, 0.5, 0.75)))

# Table `POS-TAG` :
pragmatique_df %>%
  reframe(pos=names(table(`POS-TAG`)),
          freq=table(`POS-TAG`))

# Statistiques `POS-TAG` :
pragmatique_df %>%
  summarize(n_cat_pos=length(table(`POS-TAG`)),
            ent_pos=Entropy(table(`POS-TAG`)), 
            var_pos=2^Entropy(table(`POS-TAG`)))

# Covariance et corrélation entre Durée et n_syllabes :
pragmatique_df %>%
  summarize(cov=cov(Durée, n_syllabes), cor=cor(Durée, n_syllabes))

# Table 
table(pragmatique_df$Lemme, pragmatique_df$`POS-TAG`)

####---- 3. Groupes ----####

# Moyenne de Durée par Lemme
group1_df = pragmatique_df %>%
  group_by(`POS-TAG`, Lemme) %>%
  summarize(m_duree=mean(Durée))
group1_df  

# Moyenne de Durée par POS
group1_df %>%
  summarize(m_duree=mean(m_duree))

# Moyenne de n_syllabes par POS 
pragmatique_df %>%
  group_by(`POS-TAG`) %>%
  summarize(m_n_syllabes=mean(n_syllabes))

# ------------------------------------------------------------------------------
#
#   Corrigé Exercices 8
#
#     Guillaume Guex
#
# ------------------------------------------------------------------------------


####---- 1. Chargement, création des objets `quanteda`, indices ----####

# Chargement des librairies :
library(tidyverse)
library(readtext)
library(quanteda)
library(quanteda.textstats)
library(quanteda.textplots)

# Chargement et renommage des éléments
texts_df = readtext("data/20min/*.txt")
  
# Création des objets corpus et tokens :
corpus_obj = corpus(texts_df)
tokens_obj = tokens(corpus_obj)

# Diversité 
textstat_lexdiv(tokens_obj, measure="MATTR") %>%
  arrange(MATTR)

# Lisibilité :
textstat_readability(corpus_obj, measure=c("meanSentenceLength", 
                                           "meanWordSyllables")) %>%
  arrange(meanSentenceLength)


####---- 2. Collocations et Concordance ----####

# Collocations
colloc_df = textstat_collocations(corpus_obj, size=2) %>%
  arrange(desc(count))
colloc_df

# Concordance
kwic_obj = kwic(tokens_obj, phrase("le président"))
View(kwic_obj)

# Graphique des présences
kwic_obj = kwic(tokens_obj, phrase("de la"))
textplot_xray(kwic_obj)

####---- 3. Matrice documents-termes et spécificités ----####

# Nouvel objet tokens :
tokens_new_obj = tokens(corpus_obj, remove_punct=T, remove_symbols=T, 
                        remove_numbers=T, remove_url=T, 
                        remove_separators=T)

# On sépare par apostrophe et on supprime les stopwords :
stopwords = readLines("data/stopwords/frenchST.txt")
tokens_new_obj = tokens_new_obj %>%
  tokens_split("'") %>%
  tokens_remove(stopwords)

# Matrice documents-termes :
dfm_obj = dfm(tokens_new_obj)
dfm_obj

# Plots 1, 3, 6, 13 :
textplot_keyness(textstat_keyness(dfm_obj, target=1))
textplot_keyness(textstat_keyness(dfm_obj, target=3))
textplot_keyness(textstat_keyness(dfm_obj, target=5))
textplot_keyness(textstat_keyness(dfm_obj, target=13))

# Wordcloud
textplot_wordcloud(dfm_obj, min_count=10)

####---- 4. Co-occurrences ----####

# L'objet tokens avec minuscules :
tokens_low_obj = tokens_tolower(tokens_new_obj)

# Matrice des co-occurrences :
fcm_obj = fcm(tokens_low_obj, context="window", window=5)

# Sélections des types :
top_types_names = tokens_low_obj %>%
  dfm() %>%
  topfeatures(n=100) %>%
  names()
top_types_names

# Graphe (avec 3 occurences, il est bien)
fcm_filtered_obj = fcm_select(fcm_obj, top_types_names)
textplot_network(fcm_filtered_obj, min_freq=3)


# ------------------------------------------------------------------------------
#
# TP: Introduction à l'analyse de données en sciences humaines et sociales
#
#   Corrigé Exercices 7
#
#     Guillaume Guex
#
# ------------------------------------------------------------------------------


####---- 1. Chargement des documents XML ----####

# Chargement des librairies :
library(tidyverse)
library(udpipe)
library(xml2)
library(xmlconvert)

# Dossier du corpus :
corpus_folder = "data/Nicolas_Boileau/"
# Lister les éléments
corpus_file_names = list.files(corpus_folder)

# Création d'un tibble vide :
corpus_token_df = tibble(
  document = character(),
  word = character(),
  pos = character(),
  lemma = character()
)

# Boucle sur les fichiers et chargement :
for(file_name in corpus_file_names){
  
  # Le chemin d'accès du fichier :
  file_path = paste0(corpus_folder, file_name)
  
  # Chargement du fichier XML :
  document_df = xml_to_df(file_path, 
                          records.tags="x:wf", 
                          fields="attributes")
  
  # Transformation en tibble et ajout du nom du document :
  document_df = as_tibble(document_df) %>%
    mutate(document=file_name)
  
  # Ajout à `corpus_token_df` :
  corpus_token_df = corpus_token_df %>%
    add_row(document_df)
}

# Affichage :
View(corpus_token_df)

# Nombre de Tokens, Types et Lemmes 

# Tokens :
corpus_token_df %>%
  group_by(document) %>%
  summarise(n_tokens=n())

# Types :
corpus_token_df %>%
  group_by(document) %>%
  count(str_to_lower(word)) %>%
  summarise(n_types=n())

# Lemmes :
corpus_token_df %>%
  group_by(document) %>%
  count(lemma) %>%
  summarise(n_lemmes=n())

####---- 2. Annotations automatiques ----####

# Extraction des textes bruts :
textes = corpus_token_df %>% 
  group_by(document) %>%
  summarise(texte=str_c(word, collapse=" ")) %>%
  .$texte

# Affichage des 100 premiers caractères :
str_sub(textes, 1, 100)

# Chargement du modèle :
udpipe_model = udpipe_load_model(
  "data/models/french-gsd-ud-2.5-191206.udpipe")

# Annotations :
udpipe_res = udpipe_annotate(udpipe_model, x=textes, doc_id=corpus_file_names, 
                             trace=T)

# Création du tibble :
corpus_token_df2 = as_tibble(as.data.frame(udpipe_res))

# Affichage :
View(corpus_token_df2)

# On voit que l'annotation obtenue par `udpipe` avec le modèle "french-gsd" 
# n'est pas adaptée au français classique, l'annotation donnée par frantext est 
# plus pertinente dans ce cadre. Cependant, la segmentation par phrases est 
# contenue dans `corpus_token_df2`, ce qui n'est pas le cas pour 
# `corpus_token_df`.



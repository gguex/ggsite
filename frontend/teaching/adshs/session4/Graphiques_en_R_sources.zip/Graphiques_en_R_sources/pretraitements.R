# Cours 4
# Pré-traitements sur "sociolinguistique_raw.xlsx" 
# résultant en "sociolinguistique_v2.csv"
# Auteur: Guillaume Guex

# Librairies nécessaires

library(tidyverse)
library(readxl)
library(janitor)

# Chargement des données 

raw_df = read_excel("data/sociolinguistique_raw.xlsx")

# Retrait des lignes et colonnes vides
final_df = raw_df %>%
  remove_empty(c("rows", "cols"))

# Changement des noms avec la table d'encodage 

lookup_df = read_csv("data/lookup_table.csv")
lookup_vec = deframe(lookup_df)
final_df = final_df %>%
  rename(any_of(lookup_vec))

# Suppression des colonnes inutiles

final_df = final_df %>%
  select(-mail, -mots_plus, -outils)

# Création de nouvelles variables duree, duree_num

final_df = final_df %>%
  mutate(duree = h_fin - h_deb) %>%
  mutate(duree_num = as.numeric(duree))

# Traitement de l'année

final_df = final_df %>%
  mutate(annee=str_extract(annee, regex("\\d{4}"))) %>%
  mutate(annee=as.numeric(annee))

# Traitement des mots

final_df = final_df %>%
  separate(mots, into=paste0("mot_", 1:39), sep=";", fill="right") %>%
  pivot_longer(cols=mot_1:mot_39, 
               names_to="place", 
               values_to="word", 
               values_drop_na=T) %>%
  mutate(word = str_squish(word)) %>%
  filter(word != "") %>%
  select(-place) %>%
  mutate(const = 1) %>%
  pivot_wider(names_from="word", values_from=const, values_fill=0)

# Traitement de la variable milieu (tiré de Exercices 2)

final_df = final_df %>%
  separate(milieu, into=paste0("r_", 1:5), sep=";", fill="right") %>%
  pivot_longer(cols=r_1:r_5, 
               names_to="place", 
               values_to="modality",
               values_drop_na=T) %>%
  mutate(modality = str_squish(modality)) %>%
  filter(modality != "") %>%
  select(-place) %>%
  mutate(const=1) %>%
  pivot_wider(names_from=modality, values_from=const, values_fill=0) %>%
  rename(m_amis="Avec les amis",
         m_prof="Milieu professionnel",
         m_fam="Milieu familial",
         m_autre="Autre")

# Sauvegarde de la table pré-traitée

write_csv(final_df, "data/sociolinguistique_v2.csv")


# ------------------------------------------------------------------------------
#
#   Corrigé Exercices 1
#
#     Guillaume Guex
#
# ------------------------------------------------------------------------------

####---- 1. R, une calculette ----####

# Calcul
( cos(pi/3)^9 / (sqrt(854) + 23) )^(-1/2)

# Condition logique
(7 < 18) & ((4 == 5) | !(10 <= 5))

####---- 2. Les vecteurs ----####

# Création a, b et c
a = c(3, 5, 4, 9)
b = c(8, 7, 5, 5)
c = c(4, 12, 7, 8)

# Création vecteur d
d = seq(2, 5, 0.2)

# Inverser et diviser b
rev(b) / 100

# Diviser c par a, extraire composantes
e = c / a
e[e > 1]

####---- 3. Les listes ----####

# Créer la liste
list_1 = list(a, b, c)

# Renommer ses éléments
names(list_1) = c("vecteur_1", "vecteur_2", "vecteur_3")

# Additionner ses éléments
list_1$vecteur_1 + list_1$vecteur_2 + list_1$vecteur_3

####---- 4. Les dataframes ----####

# Chargement de la libraire et le dataset
library(readxl)
df = read_excel("internet.xlsx", col_names=F)

# Changement des noms des colonnes
names(df) = c("nom", "genre", "age", "heures_internet")

# Transformation de la colonne "heures_internet" en variable numérique
df$heures_internet = as.numeric(df$heures_internet)

# Ajouter Georges
new_row = data.frame(nom="Georges", genre="M", age=35, heures_internet=2.3)
df = rbind(df, new_row)

# Calculer la moyenne des heures pour les femmes
mean(df[df$genre == "F", ]$heures_internet)

# Calculer la moyenne pour tout le monde et créer la variable variation
mean_internet = mean(df$heures_internet)
df$variation = df$heures_internet - mean_internet

# Sauvegarde de la table en csv sans le numéro des lignes
write.csv(df, "internet_out.csv", row.names=F)

####---- 5. Création de fonctions : la suite de Fibonacci ----####

fibo = function(n){
  
  # Vérification que la valeur n'est pas négative
  if(n < 0){
    warning("La valeur entrée doit être de 0 ou plus")
    return(0)
  }
  # Vérification que la valeur est un entier
  if(round(n) != n){
    warning("La valeur entére doit être un entier")
    n = round(n)
  }
  # Si 0, retour de 0
  if(n == 0){
    return(0)
  }
  # Si 1, retour de 0, 1
  if(n == 1){
    return(c(0, 1))
  }
  
  # Sinon, on commence avec 0, 1
  reponse = c(0, 1)
  
  # Et on boucle pour construire les prochaines valeurs  
  for(i in 2:n){
    # Calcul du prochain élément
    prochain_element = reponse[i] + reponse[i-1]
    # Ajout du prochain élément dans le vecteur
    reponse = c(reponse, prochain_element)
  }
  
  # Retour de la réponse
  return(reponse)
}

# Test de la fonction 
fibo(10)

# ------------------------------------------------------------------------------
#
#   Corrigé Exercices 13
#
#     Guillaume Guex
#
# ------------------------------------------------------------------------------


####---- 1. Pré-traitements et création du graphe ----####

# Chargement des librairies et seeds
set.seed(2026)
library(tidyverse)
library(igraph)
library(tidygraph)
library(ggraph)
library(nomclust)

# Chargement du jeu de données 
socioling_df = read_csv("data/sociolinguistique_v2.csv")

# Génération 
socioling_df = socioling_df %>%
  mutate(generation=case_when(annee %in% 0:1983 ~ "X",
                              annee %in% 1984:1995 ~ "Y",
                              annee %in% 1995:3000 ~ "Z"))

# Sélection des colonnes
socioling_red_df = socioling_df %>% 
  select(Hashtag:Craft)

# Matrice de dissimilarités
dissimilarity_mat = as.matrix(sm(socioling_red_df))

# Matrice de similarité 
similarity_mat = max(dissimilarity_mat) - dissimilarity_mat

# Quantile90%
quant_treshold = quantile(similarity_mat, probs=0.9)

# Matrice d'adjacence
adjacency_mat = similarity_mat
diag(adjacency_mat) = 0
adjacency_mat[adjacency_mat < quant_treshold] = 0

# Graphe entre les individus
ind_graph = as_tbl_graph(adjacency_mat, directed = FALSE)
ind_graph

####---- 2. Calcul de centralité et affichage ----####

# Ajout des colonnes "genre" et "generation"
ind_graph = ind_graph %>% 
  activate(nodes) %>%
  mutate(genre = socioling_df$genre,
         generation = socioling_df$generation)

# Calcul des degrés
ind_graph = ind_graph %>%
  activate(nodes) %>%
  mutate(degree = centrality_degree())

# Retrait des individus isolés
ind_graph = ind_graph %>%
  activate(nodes) %>%
  filter(!node_is_isolated())
 
# Affichage du graphe
ggraph(ind_graph, layout = "fr") +
  geom_edge_link(aes(edge_width = weight), alpha=0.3, color="gray50") +
  geom_node_point(aes(color=generation, size=degree, shape=genre)) +
  scale_edge_width(range = c(0.5, 3)) +
  theme_graph()

####---- 3. Détection de communautés ----####

# Calcul des communautés
ind_graph = ind_graph %>%
  activate(nodes) %>%
  mutate(community = as.factor(group_louvain(weights=weight)))

# Affichage du graphe
ggraph(ind_graph, layout = "fr") +
  geom_edge_link(aes(edge_width = weight), alpha=0.3, color="gray50") +
  geom_node_point(aes(color=community, size=degree, shape=genre)) +
  scale_edge_width(range = c(0.5, 3)) +
  theme_graph()

# Tableau de nœuds 
nodes_df = ind_graph %>%
  activate(nodes) %>%
  as_tibble()

# Tableau croisé 
cross_df = nodes_df %>%
  select(community, generation) %>%
  table()
cross_df

# Test du chi2 
chisq.test(cross_df)
# Non, le test n'est pas significatif et les communautés ne semblent pas liées aux générations.

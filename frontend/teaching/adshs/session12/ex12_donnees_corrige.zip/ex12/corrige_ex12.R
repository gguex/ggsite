# ------------------------------------------------------------------------------
#
#   Corrigé Exercices 12
#
#     Guillaume Guex
#
# ------------------------------------------------------------------------------


####---- 1. Pré-traitements ----####

# Chargement des librairies :
library(tidyverse)
library(readxl)
library(FactoMineR)
library(factoextra)
library(aricode)
library(dendextend)

# Chargement et renommage des éléments :
phonetique_df = read_excel("data/phonétique.xlsx")

# Construction de la table locuteur i
locuteur_i_df = phonetique_df %>% 
  filter(Opposition=="i(:)") %>%
  group_by(Locuteur, Voyelle) %>%
  summarise(Durée=mean(Dur_V), Region=max(Region)) %>%
  pivot_wider(names_from="Voyelle", values_from="Durée") %>%
  ungroup()

# Construction de la table numérique
locuteur_i_num_df = locuteur_i_df %>%
  select(i, `i:`) %>%
  scale() %>%
  as_tibble()

# Région
region = locuteur_i_df$Region

####---- 2. Classification ascendante hiérarchique ----####

# Distance, hclust et dendrogram
dist_mat = dist(locuteur_i_num_df, method = "euclidean")
hclust_res = hclust(dist_mat, method="ward.D2")
dendrogram = as.dendrogram(hclust_res)

# Affichage 5 groupes
dendrogram %>%
  set("branches_k_color", k=5) %>%
  plot()

# Sauvegarde des attributions à 5 groupes
groups = cutree(dendrogram, k=5)

####---- 3. Comparaison ----####

# Table de contingence
contingency_table = table(region, groups)
contingency_table

# Chi2 et ARI
chisq.test(contingency_table)
NMI(region, groups)

# ACP
pca_res = PCA(cbind(region, groups, locuteur_i_num_df), graph=F, 
              quali.sup=c(1, 2))

# Affichage de l'ACP
fviz_pca_ind(pca_res, habillage=c(1, 2))






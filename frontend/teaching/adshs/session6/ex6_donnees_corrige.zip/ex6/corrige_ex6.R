# ------------------------------------------------------------------------------
#
#   Corrigé Exercices 6
#
#     Guillaume Guex
#
# ------------------------------------------------------------------------------


####---- 1. Chargement et segmentation d'un document ----####

# Chargement des librairies :
library(tidyverse)
library(readtext)
library(quanteda)
library(quanteda.textstats)

# Chargement du texte :
text = read_file("data/20min.txt")

# Regex pour la segmentation par article :
article_split_regex = "A\\d+\\)"

# Segmentation par articles 
articles = str_split(text, article_split_regex)[[1]]

# Elimination des éléments vides, vérification de la longueur
articles = articles[articles != ""] 
length(articles)

# Suppression espaces superflus dans tous les articles
articles = str_squish(articles)

# Sauvegarde des articles
for (i in 1:length(articles)){
  write_file(articles[i], 
             paste0("data/20min/20min_", i, ".txt"))
}


####---- 2. Quanteda ----####

# Chargement du corpus
texts_df = readtext("data/20min/*.txt")

# Création d'un objet corpus :
my_corpus = corpus(texts_df)

# Statistiques :
summary(my_corpus)
textstat_summary(my_corpus)

# Création d'un objet tokens et mise en minuscules :
my_words = tokens(my_corpus, 
                  remove_punct=T, 
                  remove_symbols=T, 
                  remove_numbers=T,
                  remove_url=T,
                  split_hyphens=T) %>%
  tokens_tolower()

# Suppression des stopwords :
stopwords = read_lines("data/frenchST.txt")
my_words = my_words %>%
  tokens_remove(stopwords)
my_words

# Création d'un objet dfm :
my_dfm = dfm(my_words)
my_dfm

# Mots les plus fréquents par document :
topfeatures(my_dfm, 20, groups=docnames(my_dfm))

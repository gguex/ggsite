#----- Script pour l'extraction du texte de fichier csv issu de manifesto

library(readr)
library(stringr)

# Dossier où sont les csv
csv_folder = "data/manifesto/original"
# Dossier où mettre les fichiers txt
ouput_txt_folder = "data/manifesto/text"

# -- code

# Liste des fichiers
file_names = list.files(csv_folder)

# Boucle sur les fichiers
for(file_name in file_names){
  # Extraction du nom (sans .csv)
  name = str_split(file_name, "\\.")[[1]][1]
  # Lecture du fichier
  text_df = read.csv(paste0(csv_folder, "/", file_name))
  # Ecriture du texte 
  write_lines(text_df[, 1], paste0(ouput_txt_folder, "/", name, ".txt"))
}

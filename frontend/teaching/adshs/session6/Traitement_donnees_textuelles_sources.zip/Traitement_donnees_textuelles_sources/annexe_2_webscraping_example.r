library(tidyverse)
library(rvest)

#####################################
#### Web scraping du 20 minutes

# Définition de la page
page_url = "https://www.20min.ch/fr"
# Définition du dossier de sortie
output_dir = "data/20min"


# Récupération du code html
page_html = read_html(page_url)

# Extraction des liens d'article sur la page (balise "a" dans balise "article")
links = page_html %>% 
  html_nodes("article > a") %>% 
  html_attr("href")

# Selection des liens qui mènent sur un article (commançant par "fr/story")
article_links = links[links %>% str_detect("fr/story")]

# Préparation de vecteurs vides pour les titres et le texte
title_articles = vector("character", length(article_links))
text_articles = vector("character", length(article_links))

# Ouverture d'une serrion de navigation sur le site 
sess = html_session(page_url)

# Boucle sur les liens
for(i in seq_along(article_links)){
  
  # Ouverture d'une session en cliquant sur le lien
  sess_page = sess %>% 
    jump_to(article_links[i])
  
  # Récupération du titre de l'article (la première balise <title>)
  title_articles[i] = read_html(sess_page$url) %>%
    html_nodes("title") %>%
    html_text() %>%
    .[1] %>%
    str_squish()
  
  # Récupération du texte de l'article (les balises <p>)
  text_articles[i] = read_html(sess_page$url) %>%
    html_nodes("p") %>% 
    html_text() %>%
    str_c(collapse = "\n") %>%
    str_squish()
  
}

# On sauve les fichiers
for(i in 1:length(title_articles)){
  # On construit un titre acceptable
  title_short = str_sub(str_replace_all(str_c(title_articles[i], collapse=""), 
                                        "[ :]", "_"), 1, 15)
  
  # S'il y a bien un titre, on écrit l'article dans le fichier 
  if(title_short > 0){
    title_articles[i] %>%
      write_lines(paste0(output_dir, "/", title_short, ".txt"))
    text_articles[i] %>%
      write_lines(paste0(output_dir, "/", title_short, ".txt"), append=T)
  }
}


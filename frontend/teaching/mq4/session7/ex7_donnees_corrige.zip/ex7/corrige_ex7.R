# ------------------------------------------------------------------------------
#
#   Corrigé Exercices 7
#
#     Guillaume Guex
#
# ------------------------------------------------------------------------------


# --- 1) Chargement et traitements des données

# Chargement des packages
library(tidyverse)
library(janitor)
library(MuMIn)
library(broom)

# Chargement des données
seoul_bike = read_csv("data/SeoulBikeData.csv")

# Changement du nom des variables
seoul_bike = seoul_bike %>%
  clean_names()

# Retrait des lignes où le service de location de vélos n'est pas fonctionnel
seoul_bike = seoul_bike %>%
  filter(functioning_day == "Yes")

# Retrait des variables non pertinentes
seoul_bike = seoul_bike %>%
  select(-date, -hour, -functioning_day)

# Transformation des variables "holiday" et "season" en variables catégorielles 
seoul_bike = seoul_bike %>%
  mutate(
    holiday = as.factor(holiday),
    seasons = as.factor(seasons)
  )


# --- 1) Modèles de régression

# Modèle complet et affichage
lm_full = lm(rented_bike_count ~ ., seoul_bike)
summary(lm_full)
# Le R^2 ajusté est de 0.46, ce qui veut dire que le modèle exprime 46% de la variance du critère

# Sélection de modèles selon le BIC
options(na.action = "na.fail")
all_model_eval = dredge(lm_full, rank="BIC")

# Affichage des 5 premiers modèles 
head(all_model_eval, 5)
# Le BIC maximal est de 128334.6

# Stockage du meilleur modèle et affichage 
lm_best = get.models(all_model_eval, 1)[[1]]
summary(lm_best)
# Le R^2 ajusté est toujours 0.46%. Il n'y a pas de perte explicative alors que certaines variables
# ont été retirée

# Modalités les plus impactantes 
# La modalité "Winter" a le plus d'impact négatif sur le nombre de location et la modalité 
# "No Holiday" a le plus d'impact positif.

# Jeu de données "augmenté" avec broom
seoul_bike_aug = augment(lm_best)

# Affichage du diagramme des résidus 
ggplot(seoul_bike_aug) +
  geom_point(aes(x=.fitted, y=.resid)) +
  geom_hline(yintercept=0, linetype="dashed", color="red") +
  labs(x="Valeurs ajustées", y="Résidus", title="Diagramme des résidus")

# Ce graphique montre que qu'il n'y a pas une tendance non-linéaire particulière, la 
# **linéarité est respectée**. En revanche, pour ce qui est de la **normalité et surtout 
# l'homoscédasticité, ces hypothèses ne semblent pas être respectées**. Il faudra
# donc mettre une certaine réserve dans la communication de nos résultats. 
# 
# La forme particulière de ce graphique s'explique par le fait la variable cible
# ne peut pas être négative (on ne peut pas louer un nombre négatif de vélos), ce qui
# crée une sorte de "limite" pour les résidus négatifs. C'est ce qui rend ce modèle
# de régression moins fiable.


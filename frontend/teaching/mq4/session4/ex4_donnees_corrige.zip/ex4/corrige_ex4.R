# ------------------------------------------------------------------------------
#
#   Corrigé Exercices 4
#
#     Guillaume Guex
#
# ------------------------------------------------------------------------------



####---- 1. Préparation des données: `sociolinguistique.xlsx` ----####

# Chargement des librairies
library(tidyverse)
library(readxl)

# Chargement du jeu de données sociolinguistique
socioling_df = read_excel("data/sociolinguistique.xlsx")

# Renommer les variables
socioling_df = socioling_df %>%
  rename(annee=`Quelle est votre année de naissance ?`,
         genre=`Vous êtes`,
         amis=`Milieu où l'on utilise le plus d'anglicismes : Avec les amis`,                                                       
         professionnel=`Milieu où l'on utilise le plus d'anglicismes : Milieu professionnel`,                                              
         famille=`Milieu où l'on utilise le plus d'anglicismes : Milieu familial`,                                                
         autre=`Milieu où l'on utilise le plus d'anglicismes : Autre`)

# Calcul du nombre de milieux
socioling_df = socioling_df %>%
  mutate(nbr_milieux=rowSums(across(amis:autre)))

####---- 2. Représentations uni-variées ----####

# Barplot
ggplot(socioling_df) +
  geom_bar(aes(x=genre))

# Boxplot nbr de milieux
ggplot(socioling_df) +
  geom_boxplot(aes(y=nbr_milieux))

# Barplot nbr de milieux
ggplot(socioling_df) +
  geom_bar(aes(x=as.factor(nbr_milieux))) +
  labs(title="Répartition du nombre de milieux", 
       x="Nombre de milieux", 
       y="Effectif")

####---- 3. Représentations bi-variées ----####

# Scatterplot nombre de milieux vs année
ggplot(socioling_df) +
  geom_point(aes(x=nbr_milieux, y=annee))

# Boxplot par catégorie de nombre de milieux
ggplot(socioling_df) +
  geom_boxplot(aes(x=as.factor(nbr_milieux), y=annee))

# Répartition du nombre de milieux par genre
ggplot(socioling_df) +  
  geom_bar(aes(x=genre, fill=as.factor(nbr_milieux)), position="fill") +
  labs(title="Distribution du nombre de milieux par genre",
       x="Genre",
       y="Pourcentage",
       fill="Nombre de milieux")

####---- 4. Opérations et graphiques ----####

# Création du nouveau jeu de données
prop_oui_milieu_df = socioling_df %>%
  pivot_longer(amis:autre, names_to="milieu", values_to="oui") %>%
  group_by(milieu, genre) %>%
  summarize(prop_oui=sum(oui)/n()*100)

# Vérification du jeu de données 
View(prop_oui_milieu_df)

# Création du plot
ggplot(prop_oui_milieu_df) +
  geom_bar(aes(x=milieu, y=prop_oui, fill=genre), 
           stat="identity", position="dodge") +
  labs(title="Proportion de personnes qui utilisent des anglicismes par milieu et par genre",
       x="Milieu",
       y="Pourcentage",
       fill="Genre")

# Sauvegarde
ggsave("data/ang_milieu_genre.png", width=10, height=10)
  
  


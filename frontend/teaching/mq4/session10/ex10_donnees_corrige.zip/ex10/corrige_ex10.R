# ------------------------------------------------------------------------------
#
#   Corrigé Exercices 10
#
#     Guillaume Guex
#
# ------------------------------------------------------------------------------

# --- 1) Préparation et jeu de données

# Chargement des packages
library(tidyverse)
library(FactoMineR)
library(factoextra)
library(psych)

# Chargement du jeu de données
data(poison)
?poison

# Traitement du jeu de données
df = poison %>%
  select(-Age, -Time) %>%
  relocate(Sex)

# Création des groupes de variables pour l'AFM
grp_sizes = c(1, 6, 6)
grp_types = c("n", "n", "n")
grp_names = c("Sexe", "Symptomes", "Aliments")

#  Encodage la table en variables numériques et calcul des Alpha de Cronbach
df_encoded = df %>%
  mutate_all(as.integer) 
alpha_sympt = df_encoded %>% select(Sick:Diarrhae) %>% alpha(check.keys=TRUE)
alpha_sympt$total$raw_alpha
alpha_ali = df_encoded %>% select(Potato:Icecream) %>% alpha(check.keys=TRUE)
alpha_ali$total$raw_alpha

# --- 2) ACM

# Faire l'ACM 
mca_res = MCA(df, graph = FALSE)

# Création d'un vecteur pour les modalités
mod_var = rep(names(df), each=2)

# Affichage des modalités
fviz_mca_var(mca_res,
             repel = TRUE, 
             col.var = mod_var,
             mean.point = FALSE,
             legend.title = "Variables")

# Affichage des eta2 des variables
fviz_mca_var(mca_res, 
             choice = "mca.cor", 
             repel = TRUE)

# Affichage des ellipses
plotellipses(mca_res)

# Affichage du biplot avec individus colorés par `Sick` 
fviz_mca_biplot(mca_res,
                geom.ind = "point",
                repel = TRUE,
                mean.point = FALSE,
                col.var = mod_var,
                col.ind = mca_df$Sick,   
                addEllipses = TRUE)

# La mayonnaise semble être le coupable car elle est le seul aliment dans la direction de la maladie (gauche sur le premier axe factoriel).

# --- 3) AFM

# Effectuer l'AFM
mfa_res = MFA(df,
              name.group = grp_names,
              group = grp_sizes,
              type = grp_types,
              num.group.sup = 1,
              graph = FALSE)

# Graphique des variables qualitatives 
fviz_mfa_var(mfa_res, choice="quali.var")

# Graphique des groupes
fviz_mfa_var(mfa_res, choice="group")

# Graphique des individus partiels
fviz_mfa_ind(mfa_res,
             geom = "point",
             mean.point = FALSE,
             habillage = "Sick",
             partial = "all",
             repel = TRUE)

# Ce graphique peut être interprété de la façon suivante :
# - Les profils partiels des aliments représentent les individus lorsqu'ils ont pris leur repas (points bleu).
# - Les profils partiels des symptômes représentent leur état général après coup (points violets).
# - Les profils moyens sont à mis-chemin entre les deux, et indique le profil "aliments-maladie".
# On voit 3 groupes de profils de repas menant presque inévitablement à la maladie (en bas à gauche) : ce sont 
# certainement des personnes ayant consommé de la mayonnaise.

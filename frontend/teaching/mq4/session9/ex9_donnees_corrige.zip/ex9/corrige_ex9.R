# ------------------------------------------------------------------------------
#
#   Corrigé Exercices 9
#
#     Guillaume Guex
#
# ------------------------------------------------------------------------------

# --- 1) Préparation et jeu de données

# Chargement des packages
library(tidyverse)
library(FactoMineR)
library(factoextra)
library(aricode)

# Construction de la variable Religion
swiss_df = swiss %>%
  mutate(Religion = ifelse(Catholic > 50, "Catholic", "Protestant")) %>%
  select(-Catholic)

# Clustering dataset
clustering_df = swiss_df %>%
  select(-Religion, -Infant.Mortality) %>%
  scale()

# Visualisation du jeu de données pré-clustering
pca_res = PCA(clustering_df, graph=FALSE)
fviz_eig(pca_res, addlabels=TRUE)
fviz_pca_var(pca_res, col.var="contrib")
fviz_pca_ind(pca_res, repel=TRUE)
# Pour l'interprétation, vous pouvez me poser la question.

# --- 1) K-means

# Détermination du nombre de clusters avec silhouette
fviz_nbclust(clustering_df, kmeans)
# 2 groupes

# K-means avec 100 essais
kmeans_res = kmeans(clustering_df, centers=2, nstart=100)

# Affichage des résultats 
fviz_cluster(kmeans_res, data=clustering_df, repel=TRUE)

# Ajout de la variable des groupes 
swiss_w_res_df = swiss_df %>%
  mutate(clusters = factor(kmeans_res$cluster))

# Examens des variables dans les clusters
summary(aov(Fertility ~ clusters, swiss_w_res_df))
summary(aov(Agriculture ~ clusters, swiss_w_res_df))
summary(aov(Examination ~ clusters, swiss_w_res_df))
summary(aov(Education ~ clusters, swiss_w_res_df))
# La variable la plus utilisée est "Examination", la moins utilisée et "Fertility" 
# Mais elles sont toutes assez utiles.

# Examens de lien avec les varibles externes "Infant.Mortality" et "Religion"
summary(aov(Infant.Mortality ~ clusters, swiss_w_res_df))
chisq.test(table(swiss_w_res_df$Religion, swiss_w_res_df$clusters))

# Caractérisation des clusters
swiss_w_res_df %>%
  group_by(clusters) %>%
  summarise(n = n(),
            Fertility = mean(Fertility),
            Agriculture = mean(Agriculture),
            Examination = mean(Examination),
            Education = mean(Education))

# --- 2) Classification ascendante hiérarchique

# Construction de la matrice de distance
dist_mat = dist(clustering_df, method="euclidean")

# Clustering hiérarchique et dendrogramme
cah_res = hclust(dist_mat, method="ward.D2")
fviz_dend(cah_res, cex=0.5)

# Détermination du nombre de clusters avec gap stat
fviz_nbclust(clustering_df, hcut, method="gap_stat")
# 5 groupes

# Visualisation du dendrogramme coupé 
fviz_dend(cah_res, k=5, cex=0.5, color_labels_by_k=TRUE, rect=TRUE)

# Sauvegarde des groupes
swiss_w_res_df = swiss_w_res_df %>%
  mutate(clusters2 = factor(cutree(cah_res, k=5)))

# Examens des variables numériques 
summary(aov(Fertility ~ clusters2, swiss_w_res_df))
summary(aov(Agriculture ~ clusters2, swiss_w_res_df))
summary(aov(Examination ~ clusters2, swiss_w_res_df))
summary(aov(Education ~ clusters2, swiss_w_res_df))
summary(aov(Infant.Mortality ~ clusters2, swiss_w_res_df))
chisq.test(table(swiss_w_res_df$Religion, swiss_w_res_df$clusters2))

# Affichage du profile des groupes
swiss_w_res_df %>%
  group_by(clusters2) %>%
  summarise(n = n(),
            Fertility = mean(Fertility),
            Agriculture = mean(Agriculture),
            Examination = mean(Examination), 
            Education = mean(Education),
            Infant.Mortality = mean(Infant.Mortality),
            PCatholique = mean(ifelse(Religion == "Catholic", 1, 0)))

# Construction de la table des deux clusters et calcul du chi2 et du ARI
clust_clust = table(swiss_w_res_df$clusters, swiss_w_res_df$clusters2)
clust_clust
chisq.test(clust_clust)
AMI(swiss_w_res_df$clusters, swiss_w_res_df$clusters2)

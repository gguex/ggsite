# ------------------------------------------------------------------------------
#
#   Corrigé Exercices 12
#
#     Guillaume Guex
#
# ------------------------------------------------------------------------------

# ----- Exercice 1

# Chargement des packages et seed
library(tidyverse)
library(igraph)
library(tidygraph)
library(ggraph)
set.seed(2026)

# Lecture du fichier de données
cantons_df = read_csv("data/cantons2013.csv")

# Création des variables numériques standardisées
mat = cantons_df %>%
  select(pop, prop_chom, prop_naiss, prop_dec, prop_soc, croissance) %>%
  scale() %>%
  as.matrix()

# Matrice des produits scalaires
prod_scal = mat %*% t(mat)

# Nommage des lignes et colonnes
rownames(prod_scal) = cantons_df$canton
colnames(prod_scal) = cantons_df$canton 

# Cut-off 
prod_scal_cut = prod_scal
prod_scal_cut[prod_scal_cut < 1.5] = 0
diag(prod_scal_cut) = 0

# ----- Exercice 2

# Création du graph
graph_canton = as_tbl_graph(prod_scal_cut, directed = FALSE)
graph_canton

# Les poids représentent des proximités entre les cantons

# Affichage 
ggraph(graph_canton, layout = "fr") +
  geom_edge_link(aes(edge_width = weight), alpha=0.3, color="gray50") +
  geom_node_point(size=5, color="steelblue") +
  geom_node_text(aes(label = name), repel = TRUE, size = 3) +
  scale_edge_width(range = c(0.5, 3)) +
  theme_graph()

# ----- Exercice 3

# Calcule des poids inverses
graph_canton = graph_canton %>%
  activate(edges) %>%
  mutate(inv_weight = 1/weight)

# Calcul des centralités
graph_canton = graph_canton %>%
  activate(nodes) %>%
  mutate(
    degree = centrality_degree(weights=weight),
    betweenness = centrality_betweenness(weights=inv_weight),
    closeness = centrality_closeness(weights=inv_weight),
    pagerank = centrality_pagerank(weights=weight)
  )

# Sortie du tableau des centralités
w_centralities_df = graph_canton %>% 
  as_tibble()
View(w_centralities_df)

# Affichage des centralités
ggraph(graph_canton, layout = "fr") +
  geom_edge_link(aes(edge_width = weight), alpha=0.3, color="gray50") +
  geom_node_point(aes(size = degree, color = degree)) +
  geom_node_text(aes(label = name), repel = TRUE, size = 3) +
  scale_color_gradient(low = "lightblue", high = "red3") +
  scale_size(range = c(3, 11)) +
  scale_edge_width(range = c(0.5, 3)) +
  theme_graph()

# ----- Exercice 4

# Calcul des communautés
graph_canton = graph_canton %>%
  activate(nodes) %>%
  mutate(community = as.factor(group_louvain(weights=weight)))

# Affichage des communautés
ggraph(graph_canton, layout = "fr") +
  geom_edge_link(aes(edge_width = weight), alpha=0.3, color="gray50") +
  geom_node_point(aes(size = degree, color = community)) +
  geom_node_text(aes(label = name), repel = TRUE, size = 3) +
  scale_size(range = c(3, 11)) +
  scale_edge_width(range = c(0.5, 3)) +
  theme_graph()

# Il y a trois communautés que l'on pourrait définir ainsi : 
# 1. Cantons à forte activité économique et croissance.
# 2. Cantons ruraux avec faible activité économique.
# 3. Cantons particuliers (tessin, baleville, jura) ou présentant des liens entre les deux autres communautés (berne, soleure, baleville). Cette communauté pourrait presque être scindée et incluse dans les deux autres.






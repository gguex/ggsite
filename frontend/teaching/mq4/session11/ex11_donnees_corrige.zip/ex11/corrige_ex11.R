# ------------------------------------------------------------------------------
#
#   Corrigé Exercices 11
#
#     Guillaume Guex
#
# ------------------------------------------------------------------------------

# ------------- PACKAGES 

# Chargement des packages et seed
library(tidyverse)
library(class)
library(caret)
library(plot.matrix)
set.seed(2026)

# ------------- FONCTION 1 : création du dataset

create_spiral = function(n0=200, n1=100, mu=0.1, n_turn=1, center_size=0.05, spiral_size=0.95){
  n = n0 + n1
  
  # Les coordonnées des points de classe 0 
  phi0 = 2*pi*n_turn*(1:n0)/n0
  r0 = center_size + spiral_size * (1:n0)/n0
  x0 = r0 * cos(phi0) + rnorm(n0, 0, mu)
  y0 = r0 * sin(phi0) + rnorm(n0, 0, mu)
  
  # Les coordonnées des points de classe 1
  phi1 = 2*pi*n_turn*(1:n1)/n1
  r1 = center_size + spiral_size * (1:n1)/n1
  x1 = -r1 * cos(phi1) + rnorm(n1, 0, mu)
  y1 = -r1 * sin(phi1) + rnorm(n1, 0, mu)
  
  # Création du jeu de données 
  df = data.frame(x=c(x0, x1), y=c(y0, y1), class=c(rep(0, n0), rep(1, n1)))
  
  # Retour
  return(df)
}

# Création du dataset par défaut 
df = create_spiral()

# Affichage 
ggplot(df, aes(x=x, y=y, color=as.factor(class))) +
  geom_point() +
  theme_minimal()

# ------------- FONCTION 2 : knn classification with Lp dissimilarity

knn_dpow_classif = function(input_train, labels_train, input_test, p, k){
  
  # n_train, n_test
  n_train = nrow(input_train)
  n_test = nrow(input_test)
  
  # Calcul de la matrice des distances "minkowski" avec degré p
  D = as.matrix(dist(rbind(input_train, input_test), method="minkowski", p=p))
  
  # Matrice réduite test x train
  D_red = D[(n_train + 1):(n_train + n_test), 1:n_train]
  
  # On applique une fonction qui trouve le label de la majorité des voisins
  labels_test = apply(D_red, 1, function(row) round(mean(labels_train[order(row)[1:k]])))
  
  # Retour des labels 
  return(labels_test)
}

# ------------- QUESTIONS

# --- 1) Préparation des jeux d'entrainement-validation et test

# Standardisation de x et y 
df = df %>% 
  mutate(x = scale(x), y = scale(y))

# On crée les jeux d'entraînement et validation 
test_idx = createDataPartition(as.factor(df$class), p=0.2)$Resample1
df_test = df[test_idx, ]
df_train = df[-test_idx, ]

# Vérification de la taille et des proportions
nrow(df_test)
nrow(df_train)
mean(as.numeric(df_test$class))
mean(as.numeric(df_train$class))

# --- 2) Test du k-NN 

# Test de la fonction avec p=2 et k=10
labels_test = knn_dpow_classif(df_train[, 1:2], df_train$class, df_test[, 1:2], p=2, k=10)

# Comparaison avec les vraies valeurs 
mean(labels_test == df_test$class)
precision(as.factor(labels_test), as.factor(df_test$class), relevant="1")
recall(as.factor(labels_test), as.factor(df_test$class), relevant="1")
F_meas(as.factor(labels_test), as.factor(df_test$class), relevant="1")

# --- 3) Cross-validation

# Création des folds
folds_list = createFolds(df_train$class, k=4)

# Création des vecteurs de valeurs à tester
p_vec = c(0.001, 0.1, 0.5, 1, 2, 4, 10)
k_vec =  c(1, 3, 5, 7, 9, 11, 13, 15, 21, 31)

# Création de la matrice pour les résultats moyens 
results_list = list(accuracy=matrix(NA, nrow=length(p_vec), ncol=length(k_vec)),
                    precision=matrix(NA, nrow=length(p_vec), ncol=length(k_vec)),
                    recall=matrix(NA, nrow=length(p_vec), ncol=length(k_vec)),
                    F1=matrix(NA, nrow=length(p_vec), ncol=length(k_vec)))

# Double boucle sur les hyperparamètres
for(i in 1:length(p_vec)){
  for(j in 1:length(k_vec)){
    # Création des résultats intermédiaire
    inter_res_list = list(accuracy=rep(NA, length(folds_list)),
                          precision=rep(NA, length(folds_list)),
                          recall=rep(NA, length(folds_list)),
                          F1=rep(NA, length(folds_list)))
    
    # Boucle sur les folds
    for(id_fold in 1:length(folds_list)){
      
      # On récupère les indices de ce fold
      fold_idx = folds_list[[id_fold]]
      
      # On construit les jeux d'entraînement et de validation pour ce fold
      df_train_fold = df_train[-fold_idx, ]
      df_valid_fold = df_train[fold_idx, ]
      
      # On calcule les labels 
      labels_valid = knn_dpow_classif(df_train_fold[, 1:2], 
                                      df_train_fold$class, 
                                      df_valid_fold[, 1:2], 
                                      p=p_vec[i], 
                                      k=k_vec[j])
      
      # On calcule les mesures
      accuracy = mean(labels_valid == df_valid_fold$class)
      precision = precision(as.factor(labels_valid), as.factor(df_valid_fold$class), relevant="1")
      recall = recall(as.factor(labels_valid), as.factor(df_valid_fold$class), relevant="1")
      F1 = F_meas(as.factor(labels_valid), as.factor(df_valid_fold$class), relevant="1")
      
      # On les sauvegarde
      inter_res_list$accuracy[id_fold] = accuracy
      inter_res_list$precision[id_fold] = precision
      inter_res_list$recall[id_fold] = recall
      inter_res_list$F1[id_fold] = F1
      
    }
    
    # Sauvegarde des résultats finaux
    means_list = lapply(inter_res_list, mean, na.rm=TRUE)
    results_list$accuracy[i, j] = means_list$accuracy
    results_list$precision[i, j] = means_list$precision
    results_list$recall[i, j] = means_list$recall
    results_list$F1[i, j] = means_list$F1
    
  }
}

# Affichage des résultats
plot(results_list$accuracy, main="accuracy")
plot(results_list$precision, main="precision")
plot(results_list$recall, main="recall")
plot(results_list$F1, main="F1")


# --- 4) Le "meilleur modèle"

# On extrait les meilleurs paramètres pour l'exactitude
best_idx = which(results_list$accuracy == max(results_list$accuracy), arr.ind=TRUE)
cbind(p_vec[best_idx[, 1]], k_vec[best_idx[, 2]])
# Meilleurs paramètres p=2, k_vec=9

# Calcul sur le jeu de test avec jeu d'entrainement 
labels_best_test = knn_dpow_classif(df_train[, 1:2], df_train$class, df_test[, 1:2], p=2, k=9)

# Comparaison avec les vraies valeurs 
mean(labels_best_test == df_test$class)
precision(as.factor(labels_best_test), as.factor(df_test$class), relevant="1")
recall(as.factor(labels_best_test), as.factor(df_test$class), relevant="1")
F_meas(as.factor(labels_best_test), as.factor(df_test$class), relevant="1")

# Création d'une grille 
n_width = 100
df_grid = expand.grid(x = seq(min(df$x), max(df$x), length.out=n_width),
                      y = seq(min(df$y), max(df$y), length.out=n_width))
# Prédictions sur la grille
labels_grid = knn_dpow_classif(df_train[, 1:2], df_train$class, df_grid, p=4, k=7)
df_grid$class = labels_grid
# Plot final
ggplot(df, aes(x=x, y=y, color=as.factor(class), fill=as.factor(class))) +
  geom_raster(data=df_grid, alpha=0.2) +
  geom_point() +
  theme_minimal()



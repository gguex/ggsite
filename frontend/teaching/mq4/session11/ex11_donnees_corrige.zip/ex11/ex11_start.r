# ------------------------------------------------------------------------------
#
#   Début Exercices 11
#
#     Guillaume Guex
#
# ------------------------------------------------------------------------------

# ------------- PACKAGES 

# Chargement des packages et seed
library(tidyverse)
library(class)
library(caret)
library(plot.matrix)
set.seed(2026)

# ------------- FONCTION 1 : création du dataset

create_spiral = function(n0=200, n1=100, mu=0.1, n_turn=1, center_size=0.05, spiral_size=0.95){
  n = n0 + n1
  
  # Les coordonnées des points de classe 0 
  phi0 = 2*pi*n_turn*(1:n0)/n0
  r0 = center_size + spiral_size * (1:n0)/n0
  x0 = r0 * cos(phi0) + rnorm(n0, 0, mu)
  y0 = r0 * sin(phi0) + rnorm(n0, 0, mu)
  
  # Les coordonnées des points de classe 1
  phi1 = 2*pi*n_turn*(1:n1)/n1
  r1 = center_size + spiral_size * (1:n1)/n1
  x1 = -r1 * cos(phi1) + rnorm(n1, 0, mu)
  y1 = -r1 * sin(phi1) + rnorm(n1, 0, mu)
  
  # Création du jeu de données 
  df = data.frame(x=c(x0, x1), y=c(y0, y1), class=c(rep(0, n0), rep(1, n1)))
  
  # Retour
  return(df)
}

# Création du dataset par défaut 
df = create_spiral()

# Affichage 
ggplot(df, aes(x=x, y=y, color=as.factor(class))) +
  geom_point() +
  theme_minimal()

# ------------- FONCTION 2 : knn classification with Lp dissimilarity

knn_dpow_classif = function(input_train, labels_train, input_test, p, k){
  
  # n_train, n_test
  n_train = nrow(input_train)
  n_test = nrow(input_test)
  
  # Calcul de la matrice des distances "minkowski" avec degré p
  D = as.matrix(dist(rbind(input_train, input_test), method="minkowski", p=p))
  
  # Matrice réduite test x train
  D_red = D[(n_train + 1):(n_train + n_test), 1:n_train]
  
  # On applique une fonction qui trouve le label de la majorité des voisins
  labels_test = apply(D_red, 1, function(row) round(mean(labels_train[order(row)[1:k]])))
  
  # Retour des labels 
  return(labels_test)
}

# ------------- QUESTIONS

# (A vous de faire la suite)




# ------------------------------------------------------------------------------
#
#   Corrigé Exercices 8
#
#     Guillaume Guex
#
# ------------------------------------------------------------------------------

# Chargement des packages
library(tidyverse)
library(readxl)
library(FactoMineR)
library(factoextra)
library(ggrepel)

# Chargement des données
ph_df = read_excel("data/phonétique.xlsx")

# --- 1) Analyse en composantes principales

# Création de la table locuteur, voyelle
ph_acp_df = ph_df %>%
  group_by(Locuteur, Voyelle) %>%
  summarise(
    Region=max(Region),
    Sexe=max(Sexe),
    Age=mean(Age),
    F1 = mean(F1),
    Dur_V = mean(Dur_V)
  )

# Pivot de la table pour avoir une ligne par locuteur et des colonnes pour chaque voyelle
ph_acp_df = ph_acp_df %>%
  pivot_wider(names_from = Voyelle, values_from = c(F1, Dur_V)) %>%
  column_to_rownames("Locuteur")
ph_acp_df

# ACP 
acp_res = PCA(ph_acp_df, graph = FALSE, quali.sup=c("Region", "Sexe"), quanti.sup=c("Age"))

# Affichage du screeplot 
fviz_eig(acp_res)

# Affichage du cercle des corrélations
fviz_pca_var(acp_res, repel = TRUE)

# Affichage des individus avec les variables supplémentaires
fviz_pca_ind(acp_res, repel = TRUE, habillage = "Region")
fviz_pca_ind(acp_res, repel = TRUE, habillage = "Sexe")
fviz_pca_ind(acp_res, repel = TRUE, col.ind = ph_acp_df$Age,
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"))


# Interprétations :
# Le F1 de toutes les voyelles et en direction en haut à droite, La durée en bas à droite.
# Les régions : Haute-savoie/Genève plutôt avec des F1 faibles (sons graves) et une durée faible, 
# Martigny plutôt avec F1 élevé (son aigu) et durée élevée.
# Le sexe : comme attendu, surtout dispersé selon les F1.
# L'age : la, c'est plutôt la durée de prononciation qui s'observe.

# --- 2) MDS

# Création du jeu de données
ph_mds_df = ph_df %>%
  group_by(Voyelle) %>%
  summarise(
    F1 = mean(F1),
    F2 = mean(F2),
    F3 = mean(F3)
  ) %>%
  column_to_rownames("Voyelle") %>%
  scale()

# Création d'une matrice de distance 
ph_dist = as.matrix(dist(ph_mds_df))

# Chargement de la fonction
weighted_mds = function(dist, weights=NULL, k_max=NULL) {
  
  # La taille de la matrice 
  n = nrow(dist)
  
  # Si il n'y a pas de poids ou si incompatibles, on pose de poids uniformes
  if (is.null(weights) || length(weights) != n) {
    weights = rep(1, n)
  }
  
  # On normalise les poids 
  weights = weights / sum(weights)
  
  # Si k_max n'est pas spécifié ou est supérieur à n-1, on le fixe à n-1
  if (is.null(k_max) || k_max > (n-1)) {
    k_max = n-1
  }
  
  # Calcul des produits scalaires
  H = diag(n) - matrix(1/n, n, n)
  B = -0.5 * H %*% (dist^2) %*% H
  
  # Décomposition spectrale
  eigen_B = eigen(B)
  eigen_val = eigen_B$values
  eigen_vec = eigen_B$vectors
  
  # Suppression des valeurs propres négatives (si non-euclidien)
  eigen_val[eigen_val < 0] = 0
  
  # Reconstruction des coordonnées (1 à k_max seulement)
  coord = eigen_vec[, 1:k_max] %*% diag(sqrt(eigen_val[1:k_max]))
  
  # On retourne les valeurs propres et les coordonnées
  return(list(eigenvalues=eigen_val, coordinates=coord))
}
# Application du MDS
mds_res = weighted_mds(ph_dist)

# Pourcentage d'inertie 
round(mds_res$eigenvalues / sum(mds_res$eigenvalues) * 100, 2)

# Plot des coordonnées
ind_df = data.frame(voyelle = rownames(ph_dist), 
                    x = mds_res$coordinates[, 1], 
                    y = mds_res$coordinates[, 2])

ggplot(ind_df, aes(x = x, y = y, label = voyelle)) +
  geom_point(color = "darkred", size = 2) +
  geom_text_repel(size = 3.5, color = "darkblue") +
  theme_minimal() +
  labs(title = "MDS des voyelles avec les F1, F2 et F3",
       x = "Dimension 1",
       y = "Dimension 2")

# --- 3) AFC

# Traitement du jeu de données
ph_afc_df = ph_df %>%
  group_by(Voyelle, Region) %>%
  summarise(mean_per = mean(`%VdansM`)) 

# Création de la table
cross_table = ph_afc_df %>%
  pivot_wider(names_from = Region, values_from = mean_per, values_fill=0) %>%
  column_to_rownames("Voyelle")

# AFC
afc_res = CA(cross_table, graph=FALSE)

# Affichage du screeplot
fviz_eig(afc_res)

# Affichage du biplot
fviz_ca_biplot(afc_res, repel=TRUE)

# Réponse à la question :
# La HauteSavoir étant complétement opposé à "i:" sur le premier axe, cette région doit avoir un 
# pourcentage plus faible que la moyenne. Cela se vérifie en regardant la table de contingence.

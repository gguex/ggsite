# ------------------------------------------------------------------------------
#
#   Corrigé Exercices 6
#
#     Guillaume Guex
#
# ------------------------------------------------------------------------------

library(tidyverse)

####---- 1. Le calcul matriciel ----####

# Matrice
A = matrix(c(2, 1, 6, 7,
             1, -2, 4, -6, 
             6, 4, 8, 11,
             7, -6, 11, 14), 4, 4, byrow=T)

# Valeurs propres, vecteurs propres 
eig_A = eigen(A)
U = eig_A$vectors
L = diag(eig_A$values)

# Vérification que U est orthogonale 
round(U %*% t(U), 10)

# Déterminant de U
det(U)

# Calul de A2, vérification égalité 
A2 = U %*% L %*% t(U)
round(A2, 10) == A

# Matrice ba' 
a = c(3, 5, 4, 9)
b = c(4, 12, 7, 8)
B = b %*% t(a)
B

####---- 2. L'aléatoire ----####

# Tirage des nombres 
coord_x = runif(100, -4.5, 4.5)

# Tri
coord_x = sort(coord_x)

# Vecteur des denstités
coord_y = dnorm(coord_x)

# Tracé
ggplot() +
  geom_line(aes(x=coord_x, y=coord_y))

####---- 3. Les tests statistiques ----####


## 3.1 Préparation des données: `sociolinguistique.xlsx`

# Chargement des librairies (tidyverse déjà chargée)
library(readxl)

# Chargement du jeu de données 
socioling_df = read_excel("data/sociolinguistique.xlsx")

# Renommage
socioling_df = socioling_df %>%
  rename(annee=`Quelle est votre année de naissance ?`,
         genre=`Vous êtes`,
         q1_cat=`« Les anglicismes enrichissent la langue française »`, 
         q2_cat=`« Les anglicismes constituent une menace pour la langue française »`) 

# Création de q1 et q2
socioling_df = socioling_df %>%
  mutate(q1=case_when(q1_cat=="En désaccord total" ~ -2,
                      q1_cat=="Plutôt en désaccord" ~ -1,
                      q1_cat=="Neutre" ~ 0,
                      q1_cat=="Plutôt d'accord" ~ 1,
                      q1_cat=="Tout à fait d'accord" ~ 2), 
         q2=case_when(q2_cat=="En désaccord total" ~ -2,
                      q2_cat=="Plutôt en désaccord" ~ -1,
                      q2_cat=="Neutre" ~ 0,
                      q2_cat=="Plutôt d'accord" ~ 1,
                      q2_cat=="Tout à fait d'accord" ~ 2))

# Création de génération
socioling_df = socioling_df %>%
  mutate(generation=case_when(annee %in% 0:1983 ~ "X",
                              annee %in% 1984:1995 ~ "Y",
                              annee %in% 1995:3000 ~ "Z"))


## 3.2 Tests de moyenne groupes non-appariés

# Extraction des réponses à la question 1 par genre
q1_f = socioling_df %>%
  filter(genre=="Une femme") %>%
  .$q1
q1_h = socioling_df %>%
  filter(genre=="Un homme") %>%
  .$q1

# T-test question 1
t_test_question1_res = t.test(q1_f, q1_h)
t_test_question1_res

# Extraction des réponses à la question 2 par genre
q2_f = socioling_df %>%
  filter(genre=="Une femme") %>%
  .$q2
q2_h = socioling_df %>%
  filter(genre=="Un homme") %>%
  .$q2

# T-test question 2
t_test_question2_res = t.test(q2_f, q2_h)
t_test_question2_res

# Les moyennes ne sont pas significativement différente à 5%. Cependant, on 
# observe qu'il existe une différence significative entre les femmes et les 
# hommes au niveau 10% pour la question 1 : 
# "Les anglicismes enrichissent la langue française", où les femmes répondent
# de manière plus négative que les hommes. 


## 3.3 Tests bi-variés

# Test de corrélation
cor_test_res = cor.test(socioling_df$q1, socioling_df$q2)
cor_test_res

# Le lien est significatif à 5% entre les réponses à ces deux questions. On 
# observe que les personnes ont tendance à répondre positivement à l'une des
# questions si elles ont répondu négativement à l'autre.

# Tests du F-ratio
f_test_1_model = aov(q1 ~ generation, socioling_df)
summary(f_test_1_model)
f_test_2_model = aov(q2 ~ generation, socioling_df)
summary(f_test_2_model)

# Boxplots multiples
ggplot(socioling_df) +
  geom_boxplot(aes(x=generation, y=q1))
ggplot(socioling_df) +
  geom_boxplot(aes(x=generation, y=q2))

# On observe un lien significatif à 5% entre les questions et les générations. 
# Tendanciellement, il semblerait que ce soit la génération X qui trouve pas 
# que les anglicismes "enrichisse la langue française" et qui les considère plus
# "comme une menace".

# Table de contingence
table_q1_generation = socioling_df %>%
  select(generation, q1_cat) %>%
  table()
table_q1_generation
# Test du chi2
chisq.test(table_q1_generation)

# Le lien entre génération et question 1 n'est plus significatif à 5%.
# Ce qui à changé en considérant cette variables comme catégorielle, c'est 
# que chaque catégorie est complètement différente des autres, i.e. par rapport
# au choix "Tout à fait d'accord", choisir "plutôt d'accord" et tout aussi 
# différent que choisir "en désaccord total" (il n'y a plus la notion 
# d'éloignement d'une réponse par rapport à une autre). En perdant cette 
# relation d'ordre entre les catégories, le lien entre les réponses à la 
# question 1 et la génération s'amenuise et ne devient plus significatif à 5%.
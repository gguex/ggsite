# ------------------------------------------------------------------------------
#
#   Corrigé Exercices 2
#
#     Guillaume Guex
#
# ------------------------------------------------------------------------------

####---- 1. Chargement et création d'une unique colonne pour les modalités ----####

# Chargement de la librairie
library(tidyverse)

# Chargement du jeu de données
socio_v1_df = read_csv("data/sociolinguistique_v1.csv")

# Séparation de la colonne `milieu` en `r_1`, `r_2`, `r_3` et `r_4`
socio_v2_df = socio_v1_df %>%
  separate(milieu, into=c("r_1", "r_2", "r_3", "r_4"), sep=";")

# Pivot long de `r_1`, `r_2`, `r_3` et `r_4` en `place` et `modality`
socio_v2_df = socio_v2_df %>%
  pivot_longer(cols=r_1:r_4, 
               names_to="place", 
               values_to="modality")

####---- 2. Traitements intermédiaires ----####

# Suppression des espaces excédentaires
socio_v2_df = socio_v2_df %>%
  mutate(modality = str_squish(modality))

# Suppression des lignes non pertinentes
socio_v2_df = socio_v2_df %>%
  filter(!(modality == "" | is.na(modality)))

# Suppression de la variable `place` et création de la variable `const`
socio_v2_df = socio_v2_df %>%
  select(-place) %>%
  mutate(const=1)

####---- 3. Création des colonnes pour les modalités et sauvegarde ----####

# Création de variables binaires pour chaque modalité
socio_v2_df = socio_v2_df %>%
  pivot_wider(names_from=modality, values_from=const, values_fill=0)

# Renommage des variables binaires
socio_v2_df = socio_v2_df %>%
  rename(m_amis="Avec les amis",
         m_prof="Milieu professionnel",
         m_fam="Milieu familial",
         m_autre="Autre")

# Sauvegarde du jeu de données
write_csv(socio_v2_df, "data/sociolinguistique_v2.csv")

# -------- Script pour une mini analyse des notes 

# Chargement des librairies
library(ggplot2)
library(stringr)

# Chargement des données
notes = read.csv("data/notes.csv")

# Calcul de l'age des étudiants
notes$age = as.numeric(str_split(Sys.Date(), "-")[[1]][1]) - notes$annee

# Calcules la moyenne et de l'age et des notes
mean_age = mean(notes$age)
mean_note = mean(notes$note)

# Faire un nuage de points "age vs note" avec les moyennes sur les axes
ggplot(notes, aes(x=age, y=note)) +
  geom_point() +
  geom_text(aes(label=nom), vjust=-1, hjust=1) +
  geom_vline(xintercept = mean_age, linetype="dashed", color = "red") +
  geom_hline(yintercept = mean_note, linetype="dashed", color = "blue") +
  labs(title="Nuage de points Age vs Note",
       x=paste0("Age (Moyenne = ", round(mean_age, 2), ")"),
       y=paste0("Note (Moyenne = ", round(mean_note, 2), ")")) +
  theme_minimal()

# Sauvegarde du graphique
ggsave("data/age_vs_note.png", width=8, height=6)

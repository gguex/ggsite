-- -------------------------------------
-- -------------------------------------
-- TP-BD 11 : corrigé 
-- -------------------------------------
-- -------------------------------------

-- Chargez 'airbnb_dump.sql'

-- -------------------------------------
-- Exercice 1 : Vue
-- -------------------------------------

CREATE VIEW room_ext AS
SELECT 	r.name,
		YEAR(construction_year) AS year,
		r.price,
		r.room_type,
		h.host_name,
		n.name AS neighbourhood
FROM room r 
JOIN host h ON r.host_id = h.host_id 
JOIN neighbourhood n ON r.neighbourhood_id = n.neighbourhood_id;

-- -------------------------------------
-- Exercice 2 : Fonctions d'aggrégation
-- -------------------------------------

-- a) Prix moyen et année moyenne, ainsi que les écart-types
SELECT 	AVG(price) AS moyenne_prix,
		STD(price) AS std_prix,
		AVG(year) AS moyenne_annee,
		STD(year) AS std_annee
FROM room_ext;

-- b) Quartiles des prix 
SELECT
PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY price) OVER () AS Q1,
PERCENTILE_CONT(0.50) WITHIN GROUP (ORDER BY price) OVER () AS Q2,
PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY price) OVER () AS Q3
FROM room_ext;

-- c) Prix moyen et écart-type par quartier
SELECT 	neighbourhood,
		AVG(price) AS moyenne_prix,
		STD(price) AS std_prix
FROM room_ext
GROUP BY neighbourhood
ORDER BY AVG(price) DESC;

-- d) Distribution par quartier
-- création de la vue
CREATE VIEW neighbourhood_dist AS
SELECT 	neighbourhood,
		COUNT(*) AS freq,
		COUNT(*) / (SELECT COUNT(*) FROM room_ext) AS relative_freq
FROM room_ext
GROUP BY neighbourhood
ORDER BY COUNT(*) DESC;
-- affichage
SELECT * FROM neighbourhood_dist;

-- e) Entropie et variété effective des quartiers 
SELECT 	SUM(-LOG(relative_freq) * relative_freq) AS entropy,
		EXP(SUM(-LOG(relative_freq) * relative_freq)) AS var_eff
FROM neighbourhood_dist;
-- 46.37 de variété effective contre 171 quartiers -> la répartition est loin d'être uniforme.

-- f) Corrélation entre prix et année 
SELECT  (AVG(year*price)-AVG(year)*AVG(price))/ 
		(STD(year)*STD(price)) AS correlation
FROM room_ext 
WHERE year IS NOT NULL
AND price IS NOT NULL;


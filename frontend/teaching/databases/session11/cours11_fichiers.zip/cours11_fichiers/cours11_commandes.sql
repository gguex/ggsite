-- --------------------------------------
-- --------------------------------------
-- COURS BD : SCRIPT DU COURS 11
-- --------------------------------------
-- --------------------------------------

-- Chargez 'video_games_dump.sql' pour faire la suite de ces commandes

-- -----------------------------
-- Les vues et table temporaires
-- -----------------------------

-- Création d'une vue
CREATE VIEW game_extended AS
SELECT 	g.game_id, g.name,
		ge.name AS genre, 
		MIN(gp.release_date) AS first_release,
		ROUND(AVG(critic_score / 10), 1) AS critic_score,
		SUM(critic_count) AS critic_count,
		ROUND(AVG(user_score), 1) AS user_score,
		SUM(user_count) AS user_count,
		MAX(rating) AS rating
FROM game g 
JOIN game_platform gp ON g.game_id = gp.game_id 
JOIN genre ge ON g.genre_id = ge.genre_id 
GROUP BY g.game_id;

-- Remplacement d'une vue 
ALTER VIEW game_extended AS
SELECT 	g.game_id,
		g.name,
		ge.name AS genre, 
		MIN(gp.release_date) AS first_release,
		ROUND(AVG(critic_score / 10), 1) AS critic_score,
		SUM(critic_count) AS critic_count,
		ROUND(AVG(user_score), 1) AS user_score,
		SUM(user_count) AS user_count,
		MAX(rating) AS rating
FROM game g 
JOIN game_platform gp ON g.game_id = gp.game_id
JOIN genre ge ON g.genre_id = ge.genre_id 
GROUP BY g.game_id 
ORDER BY first_release DESC;

-- Voir la vue 
SHOW CREATE VIEW game_extended;

-- Suppresssion d'une vue
-- DROP VIEW game_extended;

-- Création d'une table temporaire
CREATE TEMPORARY TABLE nb_games_per_platform AS
SELECT p.name, COUNT(*) FROM game_platform gp
JOIN platform p ON gp.platform_id = p.platform_id 
GROUP BY gp.platform_id;

-- La voir
SELECT * FROM nb_games_per_platform;

-- ---------------------------
-- Statistiques univariées
-- ---------------------------

-- Moyenne, variance et écart-type
SELECT 	AVG(critic_score),
		VARIANCE(critic_score),
		STD(critic_score)
FROM game_extended;


-- Médiane
SELECT PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY critic_score) OVER () AS Mediane
FROM game_extended;

-- Quartiles
SELECT
PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY critic_score) OVER () AS Q1,
PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY critic_score) OVER () AS Q3
FROM game_extended;

-- Distribution 
SELECT 	ge.name AS genre,
		COUNT(*) AS freq,
		COUNT(*) / (SELECT COUNT(*) FROM game) AS relative_freq
FROM game g JOIN genre ge ON g.genre_id = ge.genre_id
GROUP BY ge.genre_id;

-- Vue préalable avec la distribution
CREATE VIEW genre_freq AS
SELECT 	ge.name AS genre,
		COUNT(*) AS freq,
		COUNT(*) / (SELECT COUNT(*) FROM game) AS relative_freq
FROM game g JOIN genre ge ON g.genre_id = ge.genre_id
GROUP BY ge.genre_id;
-- Entropie et variété effective
SELECT SUM(-LOG(relative_freq) * relative_freq) AS entropy,
	EXP(SUM(-LOG(relative_freq) * relative_freq)) AS var_eff
FROM genre_freq;

-- Corrélation
SELECT  (AVG(critic_score*user_score)-AVG(critic_score)*AVG(user_score))/ 
		(STD(critic_score)*STD(user_score)) AS correlation
FROM game_platform 
WHERE critic_score IS NOT NULL
AND user_score IS NOT NULL;



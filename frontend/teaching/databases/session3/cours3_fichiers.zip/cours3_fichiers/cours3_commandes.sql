d-- --------------------------------------
-- --------------------------------------
-- COURS BD : SCRIPT DU COURS 3
-- --------------------------------------
-- --------------------------------------

-- --------------------
-- Select
-- --------------------

-- Voir toute une table 
SELECT * FROM country_3;

-- Sélectionner des colonnes, avec éventuellement un nouvel ordre 
SELECT name, area, population FROM country_3;

-- Sélectionner les valeurs disctinctes
SELECT DISTINCT region FROM country_3;

-- --------------------
-- Ordre des lignes 
-- --------------------

-- Ordre croissant
SELECT * FROM country_3 
ORDER BY population;

-- Ordre décroissant
SELECT * FROM country_3 
ORDER BY population DESC;

-- Ordre décroissant et seul les 5 premiers résultats
SELECT * FROM country_3
ORDER BY population DESC
LIMIT 5;

-- --------------------
-- Sélection des lignes
-- --------------------

-- Sélection des lignes avec une densité plus grande que 1000
SELECT * FROM country_3 
WHERE density > 1000;

-- Sélection avec un AND
SELECT * FROM country_3 
WHERE density < 1000 AND area < 500;

-- Sélection avec un OR
SELECT * FROM country_3 
WHERE population < 20000 OR area < 100;

-- Sélection avec négation
SELECT * FROM country_3 
WHERE NOT population < 100000000;

-- Sélection des valeurs nulles 
SELECT * FROM country_2
WHERE iso3 IS NULL;

-- Sélection avec une chaîne de caractères
SELECT * FROM country_3 
WHERE region = 'EASTERN EUROPE';

-- Sélection avec un IN
SELECT * FROM country_3 
WHERE name IN ('Switzerland', 'France', 'Germany');

-- --------------------
-- LIKE
-- --------------------

-- Region se termine par 'europe' (insensible à la casse)
SELECT * FROM country_3
WHERE region LIKE '%europe';

-- Region contient 'east'
SELECT * FROM country_3
WHERE region LIKE '%east%';

-- Nom avec 4 caractères puis 'a'
SELECT * FROM country_3
WHERE name LIKE '____a';

-- ----------------
-- Tout en même temps 
-- ----------------

SELECT * FROM country_3
WHERE region LIKE '%europe'
AND density > 300
ORDER BY population DESC
LIMIT 3;


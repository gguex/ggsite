-- -------------------------------------
-- -------------------------------------
-- TP-BD 3 : corrigé 
-- -------------------------------------
-- -------------------------------------

-- -------------------------------------
-- Exercice 2, point c)
-- -------------------------------------

-- Sélection de tou.te.s les employé.e.s
SELECT * FROM employees;

-- -------------------------------------
-- Exercice 3
-- -------------------------------------

-- a) les employé.e.s dont le numéro et entre 13450 (compris) et 13560 (non-compris)
SELECT * FROM employees 
WHERE emp_no >= 13550
AND emp_no < 13560;

-- b) Les employé.e.s  dont la date de naissance est manquante.
SELECT * FROM employees 
WHERE birth_date IS NULL;

-- c) Uniquement la colonne birth_date, avec les 5 dates de naissance les plus anciennes 
--    (ATTENTION: il vous faudra omettre les valeurs manquantes).
SELECT birth_date FROM employees
WHERE birth_date IS NOT NULL
ORDER BY birth_date
LIMIT 5;
	
-- d) Les employé.e.s dont le prénom commence par z et le nom de famille se termine par z.
SELECT * FROM  employees
WHERE first_name LIKE 'z%' 
AND last_name LIKE '%z';

-- e) Le prénom, le nom et la date d'engagement des 10 dernières employées engagées avant le 1er janvier 2000, 
--    classées de la plus récemment à la moins récemment engagée.
SELECT first_name, last_name, hire_date FROM  employees
WHERE gender = 'F' 
AND hire_date < '2000-01-01'
ORDER BY hire_date DESC
LIMIT 10;


-- -------------------------------------
-- -------------------------------------
-- TP-BD 9 : corrigé 
-- -------------------------------------
-- -------------------------------------

-- Chargez 'board_games_dump.sql'

-- -------------------------------------
-- Exercice 1 : Fonctions
-- -------------------------------------

-- a) Les jeux avant 1000
SELECT * FROM game
WHERE published_date < 1000;

-- b) Modification de ces entrées en NULL, vérification
UPDATE game 
SET published_date = NULL 
WHERE published_date < 1000;

-- c) Modification de 'published_date' en chaînes de caractères
ALTER TABLE game 
MODIFY published_date VARCHAR(40);

-- d) Ajout de '-01-01' à 'published_date'
UPDATE game 
SET published_date = CONCAT(published_date, '-01-01'); 

-- e) Conversion en date 
ALTER TABLE game 
MODIFY published_date DATE;

-- -------------------------------------
-- Exercice 2 : Fonctions d'aggrégation
-- -------------------------------------

-- a) Nombre de jeux avant 1900
SELECT COUNT(*) FROM game
WHERE published_date < '1900-01-01';

-- b) Jeux les plus récents et les plus vieux (sans les NULL)
SELECT * FROM game 
WHERE published_date = 
(SELECT MAX(published_date) FROM game);

SELECT * FROM game 
WHERE published_date = 
(SELECT MIN(published_date) FROM game);

-- c) Note moyenne et déviation standard 
SELECT AVG(average_rating), STD(average_rating) FROM game;

-- d) Tableau jeu par catégorie
SELECT * FROM game g 
JOIN has_category hc ON g.game_id = hc.game_id 
JOIN category c ON hc.category_id = c.category_id;

-- e) Tableau du nombre de jeux référencés par catégorie
SELECT c.name, COUNT(*) FROM game g 
JOIN has_category hc ON g.game_id = hc.game_id 
JOIN category c ON hc.category_id = c.category_id
GROUP BY c.name;

-- f) Note moyenne et nombre de jeux par designer
SELECT d.name, 
	   COUNT(*) AS nbr_games, 
	   AVG(g.average_rating) AS avg_rating 
FROM game g 
JOIN design_by db ON g.game_id = db.game_id 
JOIN designer d ON db.designer_id = d.designer_id
GROUP BY d.designer_id 
ORDER BY avg_rating DESC;

-- -------------------------------------
-- Exercice 2 : Procédures
-- -------------------------------------

-- ATTENTION : Changez l'application de ce script sur la nouvelle base de données

-- a) Création de la base de donnée et chargement des données
-- Utilisez l'outil "Import Data" sur la base de données -> table 'categories'

-- b) Exécution du Script 'proc_unpivot.sql', application de la procédure
CALL UNPIVOT('categories', 'BGGid', '', 'temp_1_category');

-- c) Création d'une table avec les catégories
CREATE TABLE category AS
SELECT DISTINCT col_name AS name FROM temp_1_category;

-- d) Ajout de l'identifiant
ALTER TABLE category 
ADD category_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY;

-- e) 
CREATE TABLE has_category AS
SELECT tc.BGGid AS game_id,
	   c.category_id
FROM temp_1_category tc 
JOIN category c ON tc.col_name = c.name
WHERE tc.value = '1';





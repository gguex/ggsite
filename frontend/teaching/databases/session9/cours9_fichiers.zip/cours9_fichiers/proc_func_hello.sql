-- Suppression des fonctions si elles existent déjà
DROP PROCEDURE IF EXISTS HELLO_PROC;
DROP FUNCTION IF EXISTS HELLO_FUNC;

-- Changement de délimiteur
DELIMITER //

-- Procédure HELLO_PROC 
CREATE PROCEDURE HELLO_PROC(name VARCHAR(255))
BEGIN
	DROP TABLE IF EXISTS hello_table;
    CREATE TABLE hello_table AS
    SELECT CONCAT('Hello, ', name, '!');
END //

-- Fonction HELLO_FUNC
CREATE FUNCTION HELLO_FUNC(name VARCHAR(255)) 
RETURNS CHAR(50) 
DETERMINISTIC
BEGIN
	 RETURN CONCAT('Hello, ', name, '!');
END //

-- Rétablissement du délimiteur usuel
DELIMITER ;
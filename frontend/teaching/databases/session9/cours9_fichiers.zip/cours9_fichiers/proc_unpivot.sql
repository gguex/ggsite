DELIMITER //

-- UNPIVOT

DROP PROCEDURE IF EXISTS UNPIVOT //

CREATE PROCEDURE UNPIVOT(
    IN to_pivot_name VARCHAR(255),      -- The table to unpivot
    IN id_col VARCHAR(255),          -- The ID column (unique key)
    IN unpivot_cols TEXT,            -- Optional comma-separated list of columns to unpivot (can be empty)
    IN target_table VARCHAR(255)     -- The target table to store the result
)
BEGIN
    DECLARE col_name VARCHAR(255);
    DECLARE col_index INT DEFAULT 1;
    DECLARE create_sql TEXT;
    DECLARE insert_sql TEXT;
    
    -- Step 1: If no columns are provided, automatically gather all columns except the id_col
    IF unpivot_cols IS NULL OR unpivot_cols = '' THEN
        -- Use the DATABASE() function to retrieve the current database name
        SELECT GROUP_CONCAT(COLUMN_NAME)
        INTO unpivot_cols
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = to_pivot_name
        AND COLUMN_NAME != id_col;
    END IF;

    -- Variable to hold the dynamic SQL query
    SET @sql = '';

    -- Step 2: Loop through the column list and dynamically construct the SQL query
    column_loop: WHILE col_index <= (LENGTH(unpivot_cols) - LENGTH(REPLACE(unpivot_cols, ',', '')) + 1) DO
        -- Extract the current column name from the list
        SET col_name = TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(unpivot_cols, ',', col_index), ',', -1));

        -- Build the dynamic SQL query for each column
        IF col_index = 1 THEN
            -- Start with the first SELECT query
            SET @sql = CONCAT(@sql, 'SELECT ', id_col, ' AS ', id_col, ', ''', col_name, ''' AS col_name, ', col_name, ' AS value FROM ', to_pivot_name);
        ELSE
            -- Append UNION ALL for subsequent columns
            SET @sql = CONCAT(@sql, ' UNION ALL SELECT ', id_col, ', ''', col_name, ''' AS col_name, ', col_name, ' AS value FROM ', to_pivot_name);
        END IF;

        -- Increment the column index
        SET col_index = col_index + 1;
    END WHILE;
    
    -- Step 3: Create the target table to store the unpivoted results
    SET create_sql = CONCAT('CREATE TABLE IF NOT EXISTS ', target_table, ' (', id_col, ' VARCHAR(255), col_name VARCHAR(255), value VARCHAR(255));');
    PREPARE stmt_create FROM create_sql;
    EXECUTE stmt_create;
    DEALLOCATE PREPARE stmt_create;
    
    -- Step 4: Insert the unpivoted result into the target table
    -- Ensure proper dynamic SQL generation and execution
    SET insert_sql = CONCAT('INSERT INTO ', target_table, ' (', id_col, ', col_name, value) ', @sql);
    PREPARE stmt_insert FROM insert_sql;
    EXECUTE stmt_insert;
    DEALLOCATE PREPARE stmt_insert;

END;
//

DELIMITER ;

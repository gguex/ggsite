-- --------------------------------------
-- --------------------------------------
-- DEMO DE LA PROCEDURE UNPIVOT()
-- --------------------------------------
-- --------------------------------------

-- Créez une nouvelle base de données 'pre_video_games'.

-- Chargez les données 'video_games_data.csv'

-- Chargez la procedure 'proc_unpivot.sql'

-- Ajout d'un identifiant par game_platform
ALTER TABLE video_games_data
ADD game_platform_id INT NOT NULL AUTO_INCREMENT KEY;

-- Création d'une table réduite avec uniquement les ventes et l'identifiant 
CREATE TABLE temp_1_sales AS
SELECT game_platform_id, NA_Sales, EU_Sales, JP_Sales, Other_Sales FROM video_games_data;

-- Unpivot la table 
CALL UNPIVOT('temp_1_sales', 'game_platform_id', '', 'temp_2_sales');

-- Changement de type 
ALTER TABLE temp_2_sales
MODIFY value FLOAT;

-- --------------------------------------
-- --------------------------------------
-- COURS BD : SCRIPT DU COURS 9
-- --------------------------------------
-- --------------------------------------

-- Chargez 'video_games_dump.sql' pour faire la suite de ces commandes

-- ---------------------------
-- Les fonctions
-- ---------------------------

-- Le nombre Pi
SELECT PI();

-- Les arguments
SELECT ROUND(2.45);

-- Les arguments supplémentaire
SELECT ROUND(2.45, 1);

-- Les arguments supplémentaire
SELECT game_platform_id, sale_place, ROUND(quantity, 1) 
FROM sales;

-- Aide 
HELP ROUND;

-- Les opérateurs
SELECT user_count, critic_count, user_count / critic_count AS ratio_count  
FROM game_platform;

-- Combinaisons
SELECT g.name, 
       (gp.critic_score/10) - gp.user_score AS diff_score, 
	   GREATEST(gp.critic_score/10, gp.user_score) AS max_score 
FROM game_platform gp JOIN game g ON gp.game_id = g.game_id
WHERE critic_score IS NOT NULL
ORDER BY ABS(diff_score) DESC;

-- Fonctions et opérateurs numériques
-- Opérateurs : +, -, /, *, % (modulo)
-- Puissance : POW()
-- Racine carrée : SQRT()
-- Valeur absolue : ABS()
-- Arrondi : ROUND()
-- Exponentielle, logarithme : EXP(), LOG()

-- Fonctions sur les chaines de caractères
-- Concaténation : CONCAT()
-- Sous-chaine : LEFT(), RIGHT(), SUBSTR()
-- Retrait des espaces : TRIM()
-- Mise en majuscules/minuscules : UPPER(), LOWER()
-- Nombre de caractères : CHAR_LENGTH()

-- Fonctions sur les dates
-- La date et/ou l'heure actuelles : CURDATE}(), CURTIME(), NOW() 
-- Ajouter/retirer un intervalle : DATE_ADD(), DATE_SUB()
-- Différence de date : DATEDIFF()
-- Conversion d'une chaîne de caractères en date : 
SELECT STR_TO_DATE('10/03/05 14h54', '%d/%m/%y %kh%i') AS d1,
	   STR_TO_DATE('4 31 2012', '%m %d %Y') AS d2;


-- ---------------------------
-- Les fonctions d'agrégation
-- ---------------------------

-- Le nombre d'entrées
SELECT COUNT(*) FROM game_platform;

-- Le nombre de jeux Wii
SELECT COUNT(*) FROM game_platform
WHERE platform_id = 1;

-- Le nombre d'entrées distinctes
SELECT COUNT(DISTINCT game_id) FROM game_platform;

-- La note des critiques maximales 
SELECT MAX(critic_score) FROM game_platform;


-- Sélection des jeux avec note maximale
SELECT name, critic_score FROM game_platform gp
JOIN game g ON gp.game_id = g.game_id 
WHERE critic_score = 
(SELECT MAX(critic_score) FROM game_platform);

-- Combien de jeux sont en dessous de la moyenne  
SELECT COUNT(*) FROM game_platform
WHERE critic_score <
(SELECT AVG(critic_score) FROM game_platform);

-- Ventes par région 
SELECT sale_place, SUM(quantity) FROM sales
GROUP BY sale_place;

-- Nombre de jeux par plateforme
SELECT p.name, COUNT(*) FROM game_platform gp
JOIN platform p ON gp.platform_id = p.platform_id 
GROUP BY gp.platform_id;

-- Note moyenne par plateforme 
SELECT p.name, AVG(critic_score) AS mean_score FROM game_platform gp 
JOIN game g ON gp.game_id = g.game_id
JOIN platform p ON gp.platform_id = p.platform_id 
WHERE gp.critic_score IS NOT NULL
GROUP BY p.name
ORDER BY mean_score DESC;

-- ---------------------------
-- Procédures
-- ---------------------------

-- Exécutez le script 'proc_func_hello.sql'

-- Procedure HELLO_PROC, crée une nouvelle table
CALL HELLO_PROC('World par une procédure');

-- Fonction HELLO_FUNC, à utiliser avec une requête
SELECT HELLO_FUNC('World par une fonction');
	



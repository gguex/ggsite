-- --------------------------------------
-- --------------------------------------
-- COURS BD : SCRIPT DU COURS 4
-- --------------------------------------
-- --------------------------------------

-- --------------------
-- Associations 
-- --------------------

/* (ATTENTION NE PAS EXECUTER SUR VIDEO GAMES)

CREATE TABLE continent 
(
  continent_id INT NOT NULL,
  name VARCHAR(40),
  PRIMARY KEY (continent_id)
);

CREATE TABLE country 
(
  country_id INT NOT NULL,
  name VARCHAR(50),
  continent_id INT NOT NULL,
  PRIMARY KEY (country_id),
  FOREIGN KEY (continent_id) REFERENCES continent(continent_id)
);

*/

-- --------------------
-- Jointures  
-- --------------------

-- Premier JOIN
SELECT *
FROM member JOIN team
ON member.team = team.team_name;

-- Alias (avec AS)
SELECT *
FROM member AS m JOIN team AS t
ON m.team = t.team_name;

-- Alias (sans AS)
SELECT *
FROM member m JOIN team t
ON m.team = t.team_name;

-- CROSS JOIN
SELECT m.first_name, m.team, t.team_name, t.practice_night 
FROM member m JOIN team t;

-- INNER JOIN
SELECT m.first_name, m.team, t.team_name, t.practice_night 
FROM member m JOIN team t
ON m.team = t.team_name;

-- LEFT JOIN
SELECT m.first_name, m.team, t.team_name, t.practice_night 
FROM member m LEFT JOIN team t
ON m.team = t.team_name;

-- RIGHT JOIN
SELECT *
FROM team t RIGHT JOIN member m
ON t.team_name = m.team;

-- Mulitplication des lignes
SELECT *
FROM team t LEFT JOIN member m
ON t.team_name = m.team;

-- Jointure avec condition
SELECT *
FROM team t LEFT JOIN member m
ON t.team_name = m.team
WHERE m.team = "TeamA";

-- Auto-jointure
SELECT m.first_name, m.last_name,
m2.first_name AS coach_first_name, 
m2.last_name AS coach_last_name
FROM member m LEFT JOIN member m2 
ON m.coach = m2.member_id;

-- Jointures multiples
SELECT *
FROM tournament t
JOIN entry e ON t.tournament_id = e.tournament_id 
LEFT JOIN member m ON e.member_id = m.member_id;

-- Jointures multiples : condition intermédiaire
SELECT *
FROM tournament t 
JOIN entry e ON t.tournament_id = e.tournament_id 
AND e.year = 2014
LEFT JOIN member m ON e.member_id = m.member_id;

-- Tout à la fois
SELECT t.tournament_name, e.year, m.first_name, m.last_name, m.team,
m2.first_name AS coach_first_name, 
m2.last_name AS coach_last_name
FROM tournament t
JOIN entry e ON t.tournament_id = e.tournament_id 
AND e.year = 2014
LEFT JOIN member m ON e.member_id = m.member_id
LEFT JOIN member m2 ON m.coach = m2.member_id;








/*!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.4.2-MariaDB, for osx10.19 (arm64)
--
-- Host: localhost    Database: golf
-- ------------------------------------------------------
-- Server version	11.4.2-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `entry`
--

DROP TABLE IF EXISTS `entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entry` (
  `member_id` smallint(6) NOT NULL,
  `tournament_id` smallint(6) NOT NULL,
  `year` smallint(6) NOT NULL,
  PRIMARY KEY (`member_id`,`tournament_id`,`year`),
  KEY `tournament_id` (`tournament_id`),
  CONSTRAINT `entry_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`),
  CONSTRAINT `entry_ibfk_2` FOREIGN KEY (`tournament_id`) REFERENCES `tournament` (`tournament_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entry`
--

LOCK TABLES `entry` WRITE;
/*!40000 ALTER TABLE `entry` DISABLE KEYS */;
INSERT INTO `entry` VALUES
(118,24,2014),
(228,24,2015),
(258,24,2014),
(286,24,2013),
(286,24,2014),
(286,24,2015),
(415,24,2015),
(228,25,2015),
(239,25,2015),
(415,25,2013),
(228,36,2015),
(415,36,2014),
(415,36,2015),
(235,38,2013),
(235,38,2015),
(258,38,2014),
(415,38,2013),
(415,38,2015),
(235,40,2014),
(235,40,2015),
(239,40,2013),
(415,40,2013),
(415,40,2014),
(415,40,2015);
/*!40000 ALTER TABLE `entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member` (
  `member_id` smallint(6) NOT NULL,
  `last_name` char(20) DEFAULT NULL,
  `first_name` char(20) DEFAULT NULL,
  `member_type` char(20) DEFAULT NULL,
  `phone` char(20) DEFAULT NULL,
  `handicap` smallint(6) DEFAULT NULL,
  `joindate` date DEFAULT NULL,
  `coach` smallint(6) DEFAULT NULL,
  `team` char(20) DEFAULT NULL,
  `gender` char(1) DEFAULT NULL,
  PRIMARY KEY (`member_id`),
  KEY `member_type` (`member_type`),
  KEY `FK_Coach` (`coach`),
  KEY `FK_Team` (`team`),
  CONSTRAINT `FK_Coach` FOREIGN KEY (`coach`) REFERENCES `member` (`member_id`),
  CONSTRAINT `FK_Team` FOREIGN KEY (`team`) REFERENCES `team` (`team_name`),
  CONSTRAINT `member_ibfk_1` FOREIGN KEY (`member_type`) REFERENCES `member_type` (`member_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES
(118,'McKenzie','Melissa','Junior','963270',30,'2005-05-28',153,NULL,'F'),
(138,'Stone','Michael','Senior','983223',30,'2009-05-31',NULL,NULL,'M'),
(153,'Nolan','Brenda','Senior','442649',11,'2006-08-12',NULL,'TeamB','F'),
(176,'Branch','Helen','Social','589419',NULL,'2011-12-06',NULL,NULL,'F'),
(178,'Beck','Sarah','Social','226596',NULL,'2010-01-24',NULL,NULL,'F'),
(228,'Burton','Sandra','Junior','244493',26,'2013-07-09',153,NULL,'F'),
(235,'Cooper','William','Senior','722954',14,'2008-03-05',153,'TeamB','M'),
(239,'Spence','Thomas','Senior','697720',10,'2006-06-22',NULL,NULL,'M'),
(258,'Olson','Barbara','Senior','370186',16,'2013-07-29',NULL,NULL,'F'),
(286,'Pollard','Robert','Junior','617681',19,'2013-08-13',235,'TeamB','M'),
(290,'Sexton�','Thomas','Senior','268936',26,'2008-07-28',235,NULL,'M'),
(323,'Wilcox','Daniel','Senior','665393',3,'2009-05-18',NULL,'TeamA','M'),
(331,'Schmidt','Thomas','Senior','867492',25,'2009-04-07',153,NULL,'M'),
(332,'Bridges','Deborah','Senior','279087',12,'2007-03-23',235,NULL,'F'),
(339,'Young','Betty','Senior','507813',21,'2009-04-17',NULL,'TeamB','F'),
(414,'Gilmore','Jane','Junior','459558',5,'2007-05-30',153,'TeamA','F'),
(415,'Taylor','William','Senior','137353',7,'2007-11-27',235,'TeamA','M'),
(461,'Reed','Robert','Senior','994664',3,'2005-08-05',235,'TeamA','M'),
(469,'Willis','Carolyn','Junior','688378',29,'2011-01-14',NULL,NULL,'F'),
(487,'Kent','Susan','Social','707217',NULL,'2010-10-07',NULL,NULL,'F');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_type`
--

DROP TABLE IF EXISTS `member_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_type` (
  `member_type` char(20) NOT NULL,
  `fee` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`member_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_type`
--

LOCK TABLES `member_type` WRITE;
/*!40000 ALTER TABLE `member_type` DISABLE KEYS */;
INSERT INTO `member_type` VALUES
('Junior',150),
('Senior',300),
('Social',50);
/*!40000 ALTER TABLE `member_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `team` (
  `team_name` char(20) NOT NULL,
  `practice_night` char(20) DEFAULT NULL,
  `manager` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`team_name`),
  KEY `manager` (`manager`),
  CONSTRAINT `team_ibfk_1` FOREIGN KEY (`manager`) REFERENCES `member` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

LOCK TABLES `team` WRITE;
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
INSERT INTO `team` VALUES
('TeamA','Tuesday',239),
('TeamB','Monday',153);
/*!40000 ALTER TABLE `team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tournament`
--

DROP TABLE IF EXISTS `tournament`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tournament` (
  `tournament_id` smallint(6) NOT NULL,
  `tournament_name` char(20) DEFAULT NULL,
  `tournament_type` char(20) DEFAULT NULL,
  PRIMARY KEY (`tournament_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tournament`
--

LOCK TABLES `tournament` WRITE;
/*!40000 ALTER TABLE `tournament` DISABLE KEYS */;
INSERT INTO `tournament` VALUES
(24,'Leeston','Social'),
(25,'Kaiapoi','Social'),
(36,'WestCoast','Open'),
(38,'Canterbury','Open'),
(40,'Otago','Open');
/*!40000 ALTER TABLE `tournament` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'golf'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2024-10-08 15:02:32

-- -------------------------------------
-- -------------------------------------
-- TP-BD 4 : corrigé 
-- -------------------------------------
-- -------------------------------------

-- -------------------------------------
-- Exercice 1 : Jointures simples
-- -------------------------------------

-- Les jeux avec leur genre
SELECT *
FROM game ga JOIN genre ge 
ON ga.genre_id = ge.genre_id;

-- Colonnes game et genre, par ordre alphabétique
SELECT ga.name AS game, ge.name AS genre
FROM game ga JOIN genre ge 
ON ga.genre_id = ge.genre_id
ORDER BY game;

-- Jeux de stratégie uniquement 
SELECT ga.name AS game, ge.name AS genre
FROM game ga JOIN genre ge 
ON ga.genre_id = ge.genre_id
WHERE ge.name = "Strategy"
ORDER BY game;

-- -------------------------------------
-- Exercice 2 : jointures multiples
-- -------------------------------------

-- Jeux Wii, ordre de sortie
SELECT g.name, gp.release_date 
FROM game_platform gp 
JOIN platform p ON gp.platform_id = p.platform_id
AND p.name = "Wii"
JOIN game g ON gp.game_id = g.game_id
WHERE release_date != 0
ORDER BY gp.release_date;

-- Les jeux sortis par BioWare
SELECT g.name, p.name , gp.release_date
FROM developer d 
JOIN develop d2 ON d.developer_id = d2.developer_id 
AND d.name = "BioWare"
JOIN game_platform gp ON d2.game_platform_id = gp.game_platform_id 
JOIN game g ON gp.game_id = g.game_id
JOIN platform p ON gp.platform_id = p.platform_id 
ORDER BY gp.release_date;

-- Le top 20 des jeux PC les mieux vendus en europe
SELECT g.name, gp.release_date, s.quantity 
FROM game_platform gp 
JOIN platform p ON gp.platform_id = p.platform_id
AND p.name = "PC"
JOIN game g ON gp.game_id = g.game_id
JOIN sales s ON gp.game_platform_id = s.game_platform_id 
AND s.sale_place = "EU"
ORDER BY s.quantity DESC
LIMIT 20;


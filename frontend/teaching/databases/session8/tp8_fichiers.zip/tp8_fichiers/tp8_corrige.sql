-- -------------------------------------
-- -------------------------------------
-- TP-BD 8 : corrigé 
-- -------------------------------------
-- -------------------------------------

-- -------------------------------------
-- Exercice 1
-- -------------------------------------

-- a)  Création de la table vide 
CREATE TABLE game_rank
(
  rank_id INT AUTO_INCREMENT NOT NULL,
  game_name VARCHAR(256),
  platform_name VARCHAR(50),
  release_date DATE,
  user_score FLOAT,
  PRIMARY KEY (rank_id)
);

-- b) Peuplement de la table
INSERT INTO game_rank (game_name, platform_name, release_date, user_score)
SELECT g.name, p.name, gp.release_date, gp.user_score 
FROM game_platform gp 
JOIN game g ON gp.game_id = g.game_id
JOIN platform p ON gp.platform_id = p.platform_id
ORDER BY gp.user_score DESC;

-- c) Création directe
CREATE TABLE game_rank2 AS
SELECT g.name AS game_name, p.name AS platform_name, gp.release_date, gp.user_score 
FROM game_platform gp 
JOIN game g ON gp.game_id = g.game_id
JOIN platform p ON gp.platform_id = p.platform_id
ORDER BY gp.user_score DESC;

-- d) Ajout d'une clé 
ALTER TABLE game_rank2 
ADD rank_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY;

-- -------------------------------------
-- Exercice 2
-- -------------------------------------

-- a) Ajout d'appreciation
ALTER TABLE game_rank
ADD appreciation VARCHAR(10);

-- b) Remplissage de l'appreciation
UPDATE game_rank
SET appreciation = 'good'
WHERE user_score >= 8;

UPDATE game_rank
SET appreciation = 'medium'
WHERE user_score < 8 AND user_score >= 6;

UPDATE game_rank
SET appreciation = 'bad'
WHERE user_score < 6;

-- c) Retrait des lignes non-PC
DELETE FROM game_rank2 
WHERE platform_name != 'PC';

-- c) Retrait des lignes avant 2010
DELETE FROM game_rank2 
WHERE release_date < "2010-01-01";




-- --------------------------------------
-- --------------------------------------
-- COURS BD : SCRIPT DU COURS 8
-- --------------------------------------
-- --------------------------------------

-- Chargez 'golf_dump.sql' pour faire la suite de ces commandes

-- ---------------------------
-- Création de tables dérivées
-- ---------------------------

-- Création d'un schéma d'une table
CREATE TABLE phonebook
(
  entry_id INT AUTO_INCREMENT NOT NULL,
  first_name VARCHAR(100),
  last_name VARCHAR(100),
  phone_number INT,
  coach_name VARCHAR(100),
  PRIMARY KEY (entry_id)
);

-- Peuplement de la table avec 'INSERT INTO'
INSERT INTO phonebook (first_name, last_name, phone_number, coach_name)
SELECT m1.first_name, m1.last_name, m1.phone, m2.last_name 
FROM member m1 
LEFT JOIN member m2 ON m1.coach = m2.member_id;

-- Création et peuplement direct avec 'CREATE TABLE ... AS SELECT'
CREATE TABLE teamA AS
SELECT t.team_name , m.last_name, m.first_name 
FROM team t JOIN member m ON t.team_name = m.team
WHERE t.team_name = 'TeamA';


-- -----------------------
-- Modification du schéma
-- -----------------------

-- Ajouter un attribut
ALTER TABLE tournament 
ADD tournament_point INT;

-- Supprimer un attribut 
ALTER TABLE tournament 
DROP tournament_point;

-- Ajouter une clé primaire
ALTER TABLE teamA 
ADD PRIMARY KEY (last_name);

-- Supprimer une clé primaire 
ALTER TABLE teamA 
DROP PRIMARY KEY;

-- Ajout d'une nouvelle clé primaire 'AUTO_INCREMENT'
ALTER TABLE teamA 
ADD teammate_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY;

-- Suppression d'une clé étrangère 
ALTER TABLE member
DROP FOREIGN KEY member_ibfk_1;

-- Ajout d'une clé étrangère 
ALTER TABLE member
ADD FOREIGN KEY (member_type) REFERENCES member_type(member_type);

-- Changer le type et les contraintes
ALTER TABLE member
MODIFY phone INT UNSIGNED;

-- Changer le type, ERREUR 
ALTER TABLE member
MODIFY first_name INT UNSIGNED;

-- -------------------------
-- Modification des données
-- -------------------------

-- Modification d'une entrée
UPDATE member
SET last_name = 'Sexton',
	first_name = 'Tom'
WHERE member_id = 290;

-- Modification d'une entrée, ERREUR
UPDATE member
SET joindate = 'Very early'
WHERE member_id = 290;

-- Modification du type 'gender'
ALTER TABLE member
MODIFY gender VARCHAR(10);

-- Modification des données
UPDATE member
SET gender = 'Female'
WHERE gender = 'F';

UPDATE member
SET gender = 'Male'
WHERE gender = 'M';

-- Suppression de plusieurs entrées
DELETE FROM member 
WHERE member_type = 'Social';

-- Suppression de toutes les entrées
TRUNCATE phonebook; 


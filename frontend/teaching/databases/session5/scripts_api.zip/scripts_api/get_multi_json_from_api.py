import requests
import json

# SCRIPT PARAMETERS
base_url = "http://ws-old.parlament.ch/councillors"
response_type = "text/json"
response_file_name = "concillors.json"
id_range = range(1, 1000) # Max is 11509 for all councillors

# To store the json responses
json_response = []
# The loop on the id range
for id in id_range:
    # Make a session
    with requests.Session() as session:
        # Create the full url
        full_url = f"{base_url}/{id}?lang=fr&format=json"
        # Get the response
        response = session.get(full_url,
                            headers={'Accept': response_type})
        # Add in the responses if status code is ok
        if response.status_code == 200 and \
            response_type in response.headers['Content-Type']:
            json_response.append(response.json())

# Save the json to a file
with open(response_file_name, "w") as f:
    json.dump(json_response, f, ensure_ascii = True, indent=2)
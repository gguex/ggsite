import requests
import json

# SCRIPT PARAMETERS
requested_url = "https://restcountries.com/v3.1/all"
response_type = "application/json"
response_file_name = "restcountries.json"

# Make the request
with requests.Session() as session:
    # Get the response
    response = session.get(requested_url,
                           headers={'Accept': response_type})
    # Get the json
    json_response = response.json()

# Save the json to a file
with open(response_file_name, "w") as f:
    json.dump(json_response, f, ensure_ascii = True, indent=2)
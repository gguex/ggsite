import requests
import json

# Simple exemple
response = requests.get("https://en.wikipedia.org/wiki/Nobel_Prize")

# The response object has a status_code attribute
# that contains the HTTP status code.
print(response.status_code)

# The response object also has a text attribute
# that contains the HTML content of the page.
print(response.text)

# The URL of the API
REST_EU_ROOT_URL = "https://restcountries.com/v3.1"

# Test it
response = requests.get(f"{REST_EU_ROOT_URL}/name/greece")
response.json()

# The list of country codes
country_codes = ["be", "bg", "cz", "dk", "de", "ee", "ie", "gr", "es", "fr", 
                 "hr", "it", "cy", "lv", "lt", "lu", "hu", "mt", "nl", "at", 
                 "pl", "pt", "ro", "si", "sk", "fi", "se", "is", "li", "no",
                 "ch", "ba", "me", "mk", "al", "rs", "tr", "xk"]

# The country JSON list 
country_list = []

# Loop on codes
for cc in country_codes:
    # Get the response
    response = requests.get(f"{REST_EU_ROOT_URL}/alpha/{cc}")
    
    # If it worked expand the list
    if response.status_code == 200:
        country = response.json()
        country_list.extend(country)
    else:
        print(f"Unable to get data for {cc}")

# Save the JSON file
with open("countries.json", "w", encoding="utf-8") as f:
    json.dump(country_list, f, ensure_ascii=False, indent=4)
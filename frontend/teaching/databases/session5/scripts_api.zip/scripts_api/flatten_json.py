import pandas as pd
import json
from collections import defaultdict

INPUT_FILE = "concillors.json"
OUTPUT_FILE = "concillors.csv"

# Function to flatten the JSON file
def flatten_json(y):
    out = {}
    def flatten(x, name=''):
        # If the Nested key-value pair is of dict type
        if type(x) is dict:

            for a in x:
                flatten(x[a], name + a + '_')
        # If the Nested key-value pair is of list type
        elif type(x) is list:

            i = 0

            for a in x:
                flatten(a, name + str(i) + '_')
                i += 1
        else:
            out[name[:-1]] = x
    flatten(y)
    return out

# Load the JSON file
with open(INPUT_FILE, 'r') as f:
    data = json.load(f)
    
# Flatten the JSON f
if type(data) is list:
    if len(data) > 1:
        result = [flatten_json(x) for x in data]
    else:
        result = [flatten_json(x) for x in data[0]]
else:
    result = [flatten_json(data)]
    
# Convert the JSON file to a DataFrame
df = pd.json_normalize(result)

# The name of the columns
columns = df.columns

# Fonction de tri hiérarchique
def hierarchical_sort(columns):
    
    # Fonction réccursive pour trier les colonnes
    def recursive_sort(columns, depth):
        prefix_dict = defaultdict(list)
        for col in columns:
            prefix = col.split('_')[depth]
            prefix_dict[prefix].append(col)
        for prefix in prefix_dict:
            if len(prefix_dict[prefix]) > 1:
                prefix_dict[prefix] = recursive_sort(prefix_dict[prefix], depth+1)
            else:
                prefix_dict[prefix] = True
        return prefix_dict
                
    # Appeler la fonction récursive
    default_dict = recursive_sort(columns, 0)
    
    # Fonction d'applitissement du dictionnaire
    def flatten_dict(d, prefix=''):
        flat_list = []
        for key in d:
            if d[key] == True:
                flat_list.append(f"{prefix}{key}")
            else:
                flat_list.extend(flatten_dict(d[key], f"{prefix}{key}_"))
        return flat_list
    
    # Appeler la fonction d'applitissement
    return flatten_dict(default_dict)

# Trier les colonnes de la DataFrame
sorted_columns = hierarchical_sort(columns)

# Réorganiser les colonnes de la DataFrame
df = df.reindex(sorted_columns, axis=1)

# Save the flattened JSON file
df.to_csv(OUTPUT_FILE, index=False)


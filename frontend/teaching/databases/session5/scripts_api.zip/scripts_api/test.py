import requests
import pandas as pd
import json
from collections import defaultdict

print("Tout est ok ! Bravo")
CREATE TABLE country
(
  country_id INT NOT NULL,
  name VARCHAR(50) NOT NULL,
  cca2 CHAR(2) NOT NULL,
  cca3 CHAR(3),
  subregion VARCHAR(50),
  area INT,
  population INT,
  PRIMARY KEY (country_id)
);

CREATE TABLE currency
(
  currency_id INT NOT NULL,
  name VARCHAR(100) NOT NULL,
  symbol VARCHAR(10) NOT NULL,
  PRIMARY KEY (currency_id)
);

CREATE TABLE language
(
  language_id INT NOT NULL,
  name VARCHAR(50) NOT NULL,
  PRIMARY KEY (language_id)
);

CREATE TABLE flag
(
  flag_id INT NOT NULL,
  unicode CHAR(1),
  png_link VARCHAR(100),
  description VARCHAR(500),
  country_id INT NOT NULL,
  PRIMARY KEY (flag_id),
  FOREIGN KEY (country_id) REFERENCES country(country_id)
);

CREATE TABLE co2_country_year
(
  co2_production FLOAT,
  year DATE NOT NULL,
  country_id INT NOT NULL,
  PRIMARY KEY (year, country_id),
  FOREIGN KEY (country_id) REFERENCES country(country_id)
);

CREATE TABLE speaks
(
  country_id INT NOT NULL,
  language_id INT NOT NULL,
  PRIMARY KEY (country_id, language_id),
  FOREIGN KEY (country_id) REFERENCES country(country_id),
  FOREIGN KEY (language_id) REFERENCES language(language_id)
);

CREATE TABLE has_currency
(
  country_id INT NOT NULL,
  currency_id INT NOT NULL,
  PRIMARY KEY (country_id, currency_id),
  FOREIGN KEY (country_id) REFERENCES country(country_id),
  FOREIGN KEY (currency_id) REFERENCES currency(currency_id)
);

CREATE TABLE is_border_of
(
  country_id_1 INT NOT NULL,
  is_border_ofcountry_id_2 INT NOT NULL,
  PRIMARY KEY (country_id_1, is_border_ofcountry_id_2),
  FOREIGN KEY (country_id_1) REFERENCES country(country_id),
  FOREIGN KEY (is_border_ofcountry_id_2) REFERENCES country(country_id)
);
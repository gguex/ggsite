-- ----------------------------------------
-- ----------------------------------------
-- COURS BD 10 : POPULATE EUROPE COUNTRIES
-- ----------------------------------------
-- ----------------------------------------

-- --------------------------------------
-- A) Chargement des données principales
-- --------------------------------------

-- Utiliser l'outil de chargement, avec éventuellement 'MyISAM' comme 'Engine', si il y a trop de colonnes
-- Résultat : la table 'europe_countries' et la table 'co2_emissions'

-- Ajout des identifiants 
ALTER TABLE europe_countries 
ADD europe_countries_id int(11) AUTO_INCREMENT NOT NULL KEY;

ALTER TABLE co2_emissions 
ADD co2_emissions_id int(11) AUTO_INCREMENT NOT NULL KEY;

-- --------------------------------------
-- B) Remplissage des tables
-- --------------------------------------

-- -- 1) La table 'country'
-- Aucune transformation préablable, on remplit les colonnes

-- 1.1 Remplissage
INSERT INTO country(country_id, name, cca2, cca3, subregion, area, population)
SELECT europe_countries_id, name_official, cca2, cca3 , subregion, area, population 
FROM europe_countries;

-- -- 2) La table 'flag'
-- On doit modifier flag_id pour lui donner une auto_incrémentation
-- On doit également modifier 'unicode' pour entrer les données -> idéalement, on change le schéma aussi.

-- 2.1 Modification de 'flag'
ALTER TABLE flag 
MODIFY COLUMN flag_id int(11) AUTO_INCREMENT NOT NULL,
MODIFY COLUMN unicode char(2);

-- 2.2 Remplissage
INSERT INTO flag(unicode, png_link, description, country_id)
SELECT flag, flags_png, flags_alt, europe_countries_id FROM
europe_countries;

-- -- 3) Les tables 'language' et 'speaks'
-- Ici, on va construire en premier la pré-table d'association avec UNPIVOT.
-- De cette table, on construit la table language en tirant les valeurs distinctes.
-- Puis on construit la table d'association avec les bonnes clés.

-- 3.1 On isole les colonnes dans une table 'pre_language'
CREATE TABLE pre_language ENGINE=MyISAM AS
SELECT europe_countries_id, languages_deu, languages_fra, languages_nld, languages_bul, languages_ces, languages_slk, languages_dan, languages_est, languages_eng, languages_gle,
languages_ell, languages_spa, languages_cat, languages_eus, languages_glc, languages_hrv, languages_ita, languages_tur, languages_lav, languages_lit, languages_ltz,
languages_hun, languages_mlt, languages_de, languages_pol, languages_por, languages_ron, languages_slv, languages_fin, languages_swe, languages_isl, languages_nno,
languages_nob, languages_smi, languages_gsw, languages_roh, languages_bos, languages_srp, languages_cnr, languages_mkd, languages_sqi
FROM europe_countries;

-- 3.2 On effectue la procédure 'unpivot' (il faut la charger) de 'pre_language' en 'pre2_language'
CALL UNPIVOT('pre_language', 'europe_countries_id', '', 'pre2_language');

-- 3.3 On supprime les lignes ou 'value' est nulle
DELETE FROM pre2_language
WHERE value IS NULL;

-- 3.4 On ajoute l'auto-incrementation sur 'language_id' de 'language'
ALTER TABLE language 
MODIFY COLUMN language_id int(11) AUTO_INCREMENT NOT NULL;

-- 3.5 Remplissage de 'language' 
INSERT INTO language (name)
SELECT DISTINCT value 
FROM pre2_language
ORDER BY value;

-- (La commande pour avoir la table d'association)
SELECT * 
FROM pre2_language p 
JOIN language l ON p.value = l.name;

# 3.6 Remplissage de 'speaks'
INSERT INTO speaks (country_id, language_id)
SELECT p.europe_countries_id , l.language_id 
FROM pre2_language p 
JOIN language l ON p.value = l.name;

-- -- 4) La table 'is_border_of'
-- Cette table se construit avec un UNPIVOT sur les colonnes 'borders_*'. 
-- La table d'association se fait en joignant 2 fois country à cette table: on va devoir utiliser 'europe_countries_id'
-- pour le première jointure, et 'value' = 'cca' pour la deuxième.

-- 4.1 On isole les colonnes d'intérêt
CREATE TABLE pre_border AS
SELECT europe_countries_id, borders_0, borders_1, borders_2, borders_3, borders_4, borders_5, borders_6, borders_7, borders_8
FROM europe_countries;

-- 4.2 On applique UNPIVOT
CALL UNPIVOT('pre_border', 'europe_countries_id', '', 'pre2_border');

-- (la table d'association s'obtient de la sorte)
SELECT * FROM pre2_border pb
JOIN country c1 ON pb.europe_countries_id = c1.country_id
JOIN country c2 ON pb.value = c2.cca3;

-- 4.3 Remplissage de 'is_border_of'
INSERT INTO is_border_of
SELECT c1.country_id, c2.country_id FROM pre2_border pb
JOIN country c1 ON pb.europe_countries_id = c1.country_id
JOIN country c2 ON pb.value = c2.cca3;

-- -- 5) Les tables 'currency' et 'has_currency'
-- La table 'currency' présente une difficulté, dans le sens que les noms et les symboles des monnaies sont dans des colonnes séparées.
-- Il y a plusieurs manières de résoudre ce problème. Ici, nous allons dé-pivoter les colonnes "noms des monnaies" et les colonnes 
-- "symboles des monnaies" de manière indépendante, puis faire une jointure en utilisant le fait qu'il y a un identifiant de trois lettres. 
-- (p.ex EUR pour euro) dans les colonnes pour les noms et pour les symboles. Cela va nous donner la table d'association.

-- 5.1 On isole les colonnes des noms des monnaies
CREATE TABLE pre_cname AS
SELECT europe_countries_id, 
currencies_EUR_name, currencies_BGN_name, currencies_CZK_name, currencies_DKK_name, currencies_HUF_name, 
currencies_PLN_name, currencies_RON_name, currencies_SEK_name, currencies_ISK_name, currencies_CHF_name, 
currencies_NOK_name, currencies_BAM_name, currencies_MKD_name, currencies_ALL_name, currencies_RSD_name, 
currencies_TRY_name
FROM europe_countries;

-- 5.2 On isole les colonnes des symboles des monnaies
CREATE TABLE pre_csymb ENGINE=MyISAM AS
SELECT europe_countries_id, 
currencies_EUR_symbol, currencies_BGN_symbol, currencies_CZK_symbol, currencies_DKK_symbol, currencies_HUF_symbol, 
currencies_PLN_symbol, currencies_RON_symbol, currencies_SEK_symbol, currencies_ISK_symbol, currencies_CHF_symbol,
currencies_NOK_symbol, currencies_BAM_symbol, currencies_MKD_symbol, currencies_ALL_symbol, currencies_RSD_symbol, 
currencies_TRY_symbol
FROM europe_countries;

-- 5.3 On applique UNPIVOT sur 'pre_cname' -> 'pre2_cname'
CALL UNPIVOT('pre_cname', 'europe_countries_id', '', 'pre2_cname');

-- 5.4 On applique UNPIVOT sur 'pre_csymb' -> 'pre2_csymb'
CALL UNPIVOT('pre_csymb', 'europe_countries_id', '', 'pre2_csymb');

-- (La jointure va s'effectuer en utilisant l'identifiant du pays et la sous-chaine identifiant la monnaie)
SELECT * FROM pre2_cname n JOIN pre2_csymb s
ON n.europe_countries_id = s.europe_countries_id
AND SUBSTRING(n.col_name, 12, 3) = SUBSTRING(s.col_name, 12, 3);

-- 5.5 On effectue la jointure. On obtient la pre-table d'association
CREATE TABLE pre2_currency AS
SELECT n.europe_countries_id, 
	   n.value AS name,
	   s.value AS symbol
FROM pre2_cname n JOIN pre2_csymb s
ON n.europe_countries_id = s.europe_countries_id
AND SUBSTRING(n.col_name, 12, 3) = SUBSTRING(s.col_name, 12, 3)
WHERE n.value IS NOT NULL;

-- 5.6 On ajoute l'auto-incrementation sur 'currency_id'
ALTER TABLE currency 
MODIFY COLUMN currency_id int(11) AUTO_INCREMENT NOT NULL;

-- (Ici, on utilise GROUP BY, cela peut s'utiliser à la place de DISTINCT).
SELECT name, symbol FROM pre2_currency
GROUP BY name;

-- 5.7 Remplissage de 'currency'
INSERT INTO currency (name, symbol)
SELECT name, symbol FROM pre2_currency
GROUP BY name;

-- 5.8 Remplissage de 'has_currency'
INSERT INTO has_currency 
SELECT pc.europe_countries_id, c.currency_id FROM pre2_currency pc
JOIN currency c ON pc.name = c.name;

-- -- 6) La table 'co2_country_year'
-- Pour cette table, on va utiliser l'autre tableau de donnée. Il s'agira de faire un UNPIVOT, puis de transformer les colonnes
-- en types adéquats.

-- 6.1 On isole les colonnes d'intérêt  
CREATE TABLE pre_co2 AS
SELECT `GEO (Codes)` AS cca2, 
a1990, a1991, a1992, a1993, a1994, a1995, a1996, a1997, a1998, a1999, a2000, a2001, a2002,
a2003, a2004, a2005, a2006, a2007, a2008, a2009, a2010, a2011, a2012, a2013, a2014, a2015, 
a2016, a2017, a2018, a2019, a2020, a2021, a2022
FROM co2_emissions;

-- 6.2 On applique 'unpivot' sur co2_data pour créer 'pre2_co2'
CALL UNPIVOT('pre_co2', 'cca2', '', 'pre2_co2');

-- 6.3 Pour 'value', on remplace ':' par des valeurs nulles
UPDATE pre2_co2 
SET value = NULL 
WHERE TRIM(value) = ':';

-- 6.4 On change le type de 'value' en nombre à virgules
ALTER TABLE pre2_co2 
MODIFY value FLOAT;

-- 6.5 Pour 'col_name', on retire 'a' et on ajoute le mois et le jour
UPDATE pre2_co2 
SET col_name = CONCAT(SUBSTRING(col_name, 2), '-01-01');

-- 6.6 On change le type de 'col_name' en nombre à vigules
ALTER TABLE pre2_co2
MODIFY col_name DATE;

-- 6.7 Remplissage de 'co2_country_year'
INSERT INTO co2_country_year (country_id, year, co2_production)
SELECT c.country_id, p.col_name, p.value 
FROM pre2_co2 p JOIN country c ON p.cca2 = c.cca2;

-- --------------------------------------
-- C) Nettoyage
-- --------------------------------------

DROP TABLE europe_countries, co2_emissions, pre_language, pre2_language, pre_border, pre2_border, pre_cname, pre_csymb,
pre2_cname, pre2_csymb, pre2_currency, pre_co2, pre2_co2;





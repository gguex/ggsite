-- -------------------------------------
-- -------------------------------------
-- TP-BD 10 : corrigé 
-- -------------------------------------
-- -------------------------------------

-- --------------------------------------
-- A) Chargement des données principales
-- --------------------------------------

-- Création de la BD 'airbnb'.
-- Chargement du schéma 'airbnb_schema.sql'.
-- Click droit sur 'airbnb', "Importer des données", attention à définir 'host_id' comme 'VARCHAR(50)'

-- --------------------------------------
-- B) Remplissage des tables
-- --------------------------------------

-- -- 1. La table 'host'

-- 1.1 On crée une table temporaire 
CREATE TABLE pre_host AS
SELECT `host id`, `host name`, host_identity_verified FROM airbnb_data
GROUP BY `host id`;

-- 1.2 On change les valeurs de 'host_identity_verified' en binaire
UPDATE pre_host 
SET host_identity_verified = CASE WHEN host_identity_verified = 'verified' THEN 1 ELSE 0 END
WHERE host_identity_verified IS NOT NULL;

ALTER TABLE pre_host
MODIFY host_identity_verified BOOL;

-- 1.3 Remplissage de 'host'
INSERT INTO host (host_id, host_name, host_id_verified)
SELECT `host id`, `host name`, host_identity_verified FROM pre_host;

-- -- 2. La table 'neighbourhood'

-- 2.1 On ajoute un incrément à 'neighbourhood_id' de 'neighbourhood'
ALTER TABLE neighbourhood 
MODIFY COLUMN neighbourhood_id int(11) AUTO_INCREMENT NOT NULL;

-- 2.2 Remplissage 'neighbourhood'
INSERT INTO neighbourhood (name)
SELECT DISTINCT TRIM(neighbourhood) FROM airbnb_data 
WHERE neighbourhood IS NOT NULL;

-- -- 3. La table 'reviews'

-- 3.1 Sélection des attributs pour les reviews 
CREATE TABLE pre_reviews AS
SELECT id, `number of reviews`, `last review`, `mean rate` FROM airbnb_data;

-- 3.2 Ajout d'un index pour la clé 
ALTER TABLE pre_reviews
ADD review_id INT NOT NULL AUTO_INCREMENT KEY;

-- 3.3 Traitement de la date
UPDATE pre_reviews 
SET `last review` = STR_TO_DATE(`last review`, '%m/%d/%Y');

ALTER TABLE pre_reviews
MODIFY `last review` DATE;

# Remplissage de 'reviews'
INSERT INTO reviews (reviews_id, nbr_of_reviews, last_review, mean_rate)
SELECT review_id, `number of reviews`, `last review`, `mean rate` FROM pre_reviews;

-- -- 4. La table 'room'

-- 4.1 Remplissage de 'room'
INSERT INTO room
SELECT d.id, d.name, CONCAT(d.`construction year`, '-01-01'), d.price_dollars, d.`room type`, 
	   d.`host id`, n.neighbourhood_id, r.review_id 
FROM airbnb_data d
JOIN neighbourhood n ON d.neighbourhood = n.name
JOIN pre_reviews r ON d.id = r.id;

-- -- 5. Les tables de 'appliance' et 'has_appliances'

-- 5.1 Sélection des colonnes pertinentes
CREATE TABLE pre_appliance AS
SELECT id, has_tv, has_wifi, has_ac, has_washing_machine FROM airbnb_data;

-- 5.2 Application de UNPIVOT -> pre2_appliances
CALL UNPIVOT('pre_appliance', 'id', '', 'pre2_appliance');

-- 5.2 Retrait des 0 
DELETE FROM pre2_appliance 
WHERE value = 0;

-- 5.3 Traitement de 'col_name'
UPDATE pre2_appliance 
SET col_name = SUBSTR(col_name, 5);

-- 5.4 Ajout de l'auto-incrémentation à appliance
ALTER TABLE appliance 
MODIFY COLUMN appliance_id int(11) AUTO_INCREMENT NOT NULL;

-- 5.5 Remplissage de 'appliance 
INSERT INTO appliance(name)
SELECT DISTINCT col_name FROM pre2_appliance;

-- 5.6 Remplissage de 'has_appliance'
INSERT INTO has_appliances
SELECT a.appliance_id, r.room_id FROM pre2_appliance p
JOIN appliance a ON p.col_name = a.name
JOIN room r ON p.id = r.room_id;

-- --------------------------------------
-- C) Nettoyage
-- --------------------------------------

DROP TABLE airbnb_data, pre_host, pre_reviews, pre_appliance, pre2_appliance;


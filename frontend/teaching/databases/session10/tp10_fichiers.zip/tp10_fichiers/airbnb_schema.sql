CREATE TABLE host
(
  host_id VARCHAR(50) NOT NULL,
  host_name VARCHAR(50),
  host_id_verified BOOLEAN,
  PRIMARY KEY (host_id)
);

CREATE TABLE reviews
(
  reviews_id INT NOT NULL,
  nbr_of_reviews INT,
  last_review DATE,
  mean_rate INT,
  PRIMARY KEY (reviews_id)
);

CREATE TABLE neighbourhood
(
  neighbourhood_id INT NOT NULL,
  name VARCHAR(50) NOT NULL,
  PRIMARY KEY (neighbourhood_id)
);

CREATE TABLE appliance
(
  appliance_id INT NOT NULL,
  name VARCHAR(50) NOT NULL,
  PRIMARY KEY (appliance_id)
);

CREATE TABLE room
(
  room_id INT NOT NULL,
  name VARCHAR(100),
  construction_year DATE,
  price INT,
  room_type VARCHAR(50),
  host_id VARCHAR(50) NOT NULL,
  neighbourhood_id INT,
  reviews_id INT NOT NULL,
  PRIMARY KEY (room_id),
  FOREIGN KEY (host_id) REFERENCES host(host_id),
  FOREIGN KEY (neighbourhood_id) REFERENCES neighbourhood(neighbourhood_id),
  FOREIGN KEY (reviews_id) REFERENCES reviews(reviews_id)
);

CREATE TABLE has_appliances
(
  appliance_id INT NOT NULL,
  room_id INT NOT NULL,
  PRIMARY KEY (appliance_id, room_id),
  FOREIGN KEY (appliance_id) REFERENCES appliance(appliance_id),
  FOREIGN KEY (room_id) REFERENCES room(room_id)
);

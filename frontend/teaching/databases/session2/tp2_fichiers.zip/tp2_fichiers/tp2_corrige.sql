-- -------------------------------------
-- -------------------------------------
-- TP-BD 2 : corrigé 
-- -------------------------------------
-- -------------------------------------

-- -------------------------------------
-- Exercice 2
-- -------------------------------------

-- a) Créez une nouvelle base de données nommée tp2 et sélectionnez-la
CREATE DATABASE tp2;
USE tp2;

-- b) Créez une table nommée étudiant_e 
CREATE TABLE etudiant_e
(
  etudiant_e_id INT NOT NULL, 
  nom VARCHAR(50),
  prenom VARCHAR(50),
  cursus VARCHAR(100) DEFAULT '',
  info_autoeval FLOAT,
  prog_autoeval FLOAT,
  fictif BOOLEAN,
  PRIMARY KEY (etudiant_e_id)
);

-- c) Remplir la base de données 
INSERT INTO etudiant_e
VALUES
(1, 'Guillaume', 'Guex', 'Doctorat mathématiques appliquées', 7.0, 8.0, 0),
(2, 'Fictional', 'Fiction', "Création de l'imaginaire", 9.9, 9.9999, 1),
(3, 'X', 'Mr', 'Espion', 0, 0, 1);

-- d) Affichez les colonnes de la table etudiant_e, puis ses enregistrements
SHOW COLUMNS FROM etudiant_e;
SELECT * FROM etudiant_e;

-- e) Exécutez le fichier domaine-sql
SOURCE 'domaine.sql';
SHOW COLUMNS FROM domaine;
SELECT * FROM domaine;


-- -------------------------------------
-- Exercice 2 : DBeaver
-- -------------------------------------

-- a) + b)
-- VOIR VIDEO "DBeaver : importer un csv"

-- c) 
-- Clic-droit sur la base de données, puis "Refresh" : elle devrait apparaître
-- Double-clic sur la table : onglet "Properties" pour les colonnes, onglet "Data" pour les données

-- d)
SHOW COLUMNS FROM ecole;
SELECT * FROM ecole;


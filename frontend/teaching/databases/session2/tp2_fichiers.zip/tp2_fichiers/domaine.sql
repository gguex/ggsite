-- SOURCE : https://www.bfs.admin.ch/bfs/fr/home/statistiques/education-science/personnes-formation/degre-tertiaire-hautes-ecoles/universitaires.html

CREATE TABLE domaine (
  domaine_id INT UNSIGNED NOT NULL,
  nom VARCHAR(50) DEFAULT '',
  n_entrants INT DEFAULT 0,
  n_etudiant_e_s INT DEFAULT 0,
  perc_femme FLOAT,
  perc_entranger FLOAT,
  PRIMARY KEY (domaine_id)
);

INSERT INTO domaine
VALUES
(1, 'Sciences humaines et sociales', 5562, 46106, 69.2, 27.2),
(2, 'Sciences économiques', 3295, 22801, 35.3, 37.0),
(3, 'Droit', 2080, 16457, 62.0, 20.0),
(4, 'Sciences exactes et naturelles', 4903, 34898, 40.0, 47.2),
(5, 'Médecine et pharmacie', 2558, 22317, 64.3, 24.8),
(6, 'Sciences techniques', 2861, 21664, 32.8, 48.3),
(7, 'Interdisciplinaire et autre', 531, 5012, 47.4, 27.0);

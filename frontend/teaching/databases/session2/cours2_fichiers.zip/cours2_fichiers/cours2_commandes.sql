-- --------------------------------------
-- --------------------------------------
-- COURS BD : SCRIPT DU COURS 2
-- --------------------------------------
-- --------------------------------------

-- Voir les bases de données
SHOW DATABASES; 

-- Créer une base de données
CREATE DATABASE world;

-- Utiliser une base de données 
USE world; 

-- Supprimer une base de données 
DROP DATABASE world; 

-- Voir les tables (de la BD active)
SHOW TABLES; 

-- Voir les tables de world
SHOW TABLES FROM world;

-- Quitter MariaDB
EXIT;

-- Créer une table
CREATE TABLE country
(
  country_id INT, 
  name VARCHAR(100), 
  pop FLOAT,
  pib INT
);

-- Voir les colonnes
SHOW COLUMNS FROM country;

-- Supprimer la table
DROP TABLE country;

-- Entrer de données
INSERT INTO country (country_id, name, pop, pib) 
VALUES
(1, 'Suisse', 9.0, 842),
(2, 'France', 68.4, 3013),
(3, 'Allemagne', 84.7, 4429);

-- Afficher les enregistrements
SELECT * FROM country;

-- Créer une table avec contraintes
CREATE TABLE country
(
  country_id INT NOT NULL, -- pas de valeurs manquantes 
  name VARCHAR(100) UNIQUE, -- valeurs uniques
  pop FLOAT UNSIGNED, -- pas de nombres n ́egatifs
  pib INT DEFAULT 0 -- assigne une valeur par d ́efaut
);

-- Créer une table avec contraintes et une clé primaire
CREATE TABLE country
(
  country_id INT NOT NULL,
  name VARCHAR(100) UNIQUE,
  pop FLOAT UNSIGNED,
  pib INT DEFAULT 0,
  PRIMARY KEY (country_id)
);

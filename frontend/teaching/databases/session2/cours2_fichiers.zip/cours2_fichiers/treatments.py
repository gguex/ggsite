import pandas as pd

data = pd.read_csv("country_3.csv")

data["country"] = data["country"].str.strip()
data["region"] = data["region"].str.strip()

# Save the data to a new CSV file
data.to_csv("country_3.csv", index=False)